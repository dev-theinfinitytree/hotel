<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Dashboard_model extends CI_Model {
    /* Add Hotel */
    function add_hotel($hotel,$hotel_contact_details,$hotel_tax_details,$hotel_billing_settings,$hotel_general_preference){
		$query=$this->db->insert(TABLE_PRE.'hotel_details',$hotel);
		$hotel_id = $this->db->insert_id();
		$data = array(
			'hotel_id' => $hotel_id
		);
		$new_hotel_contact_details = array_merge($hotel_contact_details, $data);
		$new_hotel_tax_details = array_merge($hotel_tax_details , $data);
		$new_hotel_billing_settings = array_merge($hotel_billing_settings,$data);
		$new_hotel_general_preference = array_merge($hotel_general_preference,$data);
		$query_contact = $this->db->insert(TABLE_PRE.'hotel_contact_details',$new_hotel_contact_details);
		$query_tax = $this->db->insert(TABLE_PRE.'hotel_tax_details',$new_hotel_tax_details);
		$query_billing = $this->db->insert(TABLE_PRE.'hotel_billing_setting',$new_hotel_billing_settings);
		$query_general = $this->db->insert(TABLE_PRE.'hotel_general_preference',$new_hotel_general_preference);

        if($query){
				if($query_contact){
					if($query_tax){
						if($query_billing){
							if($query_general){
								return true;
							}else{
								return false;
							}
						}
						else{
							return false;
						}
					}
					else{
						return false;
					}
				}
				else{
					return false;
				}
				
        }else{
            return false;
        }
	}
	
	/* Ajax Hotel Email Check */
	function hotel_email_check($email){
		$query=$this->db->get_where(TABLE_PRE.'hotel_details',$email);
		
        if($query->num_rows()==1){
			
			$a = $this->db->insert_id();
			echo $a;
			exit();
            return $query->row();
        }else{ 
            return false;
        }
		
	}
	
	/* Ajax Hotel Phone Check */
	function hotel_phone_check($phone){
		$query=$this->db->get_where(TABLE_PRE.'hotel_details',$phone);
        if($query->num_rows()==1){
            return $query->row();
        }else{ 
            return false;
        }
	}
	
	/* Number of All Hotels */
	function all_hotels_row(){
		$this->db->where('hotel_status!=','D');
        $query=$this->db->get(TABLE_PRE.'hotel_details');
        if($query->num_rows()>0){
            return $query->num_rows();
        }else{
            return false;
        }
    }
    
	/* All Hotels With Pagination */
    function all_hotels(){
		/*$this->db->where('hotel_status!=','D');
        $this->db->order_by('hotel_id','desc');
		//$this->db->limit($limit,$start);
        $query=$this->db->get(TABLE_PRE.'hotel_details');
        if($query->num_rows()>0){
            return $query->result();
        }else{
            return false;
        }*/

        /*$this->db->select('*');
        $this->db->from('hotel_hotel_billing_setting');
        $this->db->join('hotel_hotel_contact_details', 'hotel_hotel_billing_setting.hotel_id = hotel_hotel_contact_details.hotel_id');*/
		
		
		$this->db->select('*');
        $this->db->from('hotel_hotel_contact_details');
		$this->db->join('hotel_hotel_details', 'hotel_hotel_contact_details.hotel_id = hotel_hotel_details.hotel_id');
        $query=$this->db->get();

        if($query->num_rows() > 0)
        {
            return $query->result();
        }
        else
        {
            return false;
        }
    }

    /* All Hotels */
    function total_hotels()
    {
        $this->db->where('hotel_status!=','D');
        $this->db->order_by('hotel_id','desc');
        $query=$this->db->get(TABLE_PRE.'hotel_details');
        if($query->num_rows()>0){
            return $query->result();
        }
        else
        {
            return false;
        }
    }
	
	/* Get Particular Hotel Information */
	function get_hotel($hotel_id)
    {
        $this->db->where('hotel_id',$hotel_id);
        $query=$this->db->get(TABLE_PRE.'hotel_details');
        if($query->num_rows()==1){
            return $query->row();
        }else{
            return false;
        }

        

    }
	
	/* Update Hotel */
	function update_hotel($hotel){
        $this->db->where('hotel_id',$hotel['hotel_id']);
        $query=$this->db->update(TABLE_PRE.'hotel_details',$hotel);
        if($query){
            return true;
        }else{
            return false;
        }
    }
	
	/* Delete Hotel (Only Status Changed) */
	function delete_hotel($hotel_id,$hotel){
        $this->db->where_in('hotel_id',$hotel_id);
        $query=$this->db->update(TABLE_PRE.'hotel_details',$hotel);
        if($query){
            return true;
        }else{
            return false;
        }
    }
	
	/* Ajax Hotel Status Update */
	function hotel_status_update($status){
		$this->db->where('hotel_id',$status['hotel_id']);
        $query=$this->db->update(TABLE_PRE.'hotel_details',$status);
        if($query){
            return true;
        }else{
            return false;
        }
	}
	
	/* All Hotel */
	function all_hotel_list(){
		$this->db->where('hotel_status!=','D');
        $this->db->order_by('hotel_name','asc');
        $query=$this->db->get(TABLE_PRE.'hotel_details');
        if($query->num_rows()>0){
            return $query->result();
        }else{
            return false;
        }
    }
	
	/* Get All User Types */
	function get_user_type(){
		$this->db->where('user_type_slug!=','SUPA');
        $query=$this->db->get(TABLE_PRE.'user_type');
        if($query->num_rows()>0){
            return $query->result();
        }else{
            return false;
        }
	}
	
	/* Add Permission */
	function add_permission($permission){
		$query=$this->db->insert_batch(TABLE_PRE.'permission_types',$permission);
        if($query){
            return true;
        }else{
            return false;
        }
	}
	
	/* Number of All Permissions */
	function all_permissions_row(){
		$this->db->group_by('permission_label');
		$this->db->where('permission_status!=','D');
        $query=$this->db->get(TABLE_PRE.'permission_types');
        if($query->num_rows()>0){
            return $query->num_rows();
        }else{
            return false;
        }
    }
    
	/* All Permissions */
    function all_permissions(){
		$this->db->group_by('permission_label');
		$this->db->where('permission_status!=','D');
        $this->db->order_by('permission_label','asc');
		//$this->db->limit($limit,$start);
        $query=$this->db->get(TABLE_PRE.'permission_types');
        if($query->num_rows()>0){
            return $query->result();
        }else{
            return false;
        }
    }
	
	/* Particular User Type Information */
	function get_user_type_by_id($user){
		$this->db->where('user_type_id',$user);
		 $query=$this->db->get(TABLE_PRE.'user_type');
        if($query->num_rows()==1){
            return $query->row();
        }else{
            return false;
        }
	}
	
	/* Particular Permission */
	function get_permission($permission_id){
        $this->db->where('permission_id',$permission_id);
        $query=$this->db->get(TABLE_PRE.'permission_types');
        if($query->num_rows()==1){
            return $query->row();
        }else{
            return false;
        }
    }
	
	/* Get All Permission By Label */
	function get_permission_info($label){
		$this->db->where('permission_label',$label);
        $query=$this->db->get(TABLE_PRE.'permission_types');
        if($query->num_rows()>0){
            return $query->result();
        }else{
            return false;
        }
	}
	
	/* Update Permission */
	function update_permission($permission){
       	$query=$this->db->update_batch(TABLE_PRE.'permission_types', $permission, 'permission_id');
        if($query){
            return true;
        }else{
            return false;
        }
    }
	
	/* Add Admin */
    function add_admin($admin){
		$query=$this->db->insert(TABLE_PRE.'admin_details',$admin);
        if($query){
            return $this->db->insert_id();
        }else{
            return false;
        }
	}
	
	/* Add User For Login */
    function add_user($user){
		$query=$this->db->insert(TABLE_PRE.'login',$user);
        if($query){
            return $this->db->insert_id();
        }else{
            return false;
        }
	}
	
	/* Add User For Login */
    function get_country(){
		$this->db->order_by('country_name','asc');
		$query=$this->db->get(TABLE_PRE.'countries');
        if($query){
            return $query->result();
        }else{
            return false;
        }
	}
	
	/* Add User For Login */
    function get_star_rating(){
		$this->db->order_by('star_rating_value','asc');
		$query=$this->db->get(TABLE_PRE.'star_rating');
        if($query){
            return $query->result();
        }else{
            return false;
        }
	}
	
	/* Ajax Username Check */
	function username_check($username){
		$query=$this->db->get_where(TABLE_PRE.'login',$username);
        if($query->num_rows()==1){
            return $query->row();
        }else{ 
            return false;
        }
	}
	
	/* Ajax Email Check */
	function email_check($email){
		$query=$this->db->get_where(TABLE_PRE.'login',$email);
        if($query->num_rows()==1){
            return $query->row();
        }else{ 
            return false;
        }
	}
	
	/* All Permission Label Applicable*/
	function admin_permission_label($permission_users){
		$this->db->like('permission_users',$permission_users,'both');
		$this->db->group_by('permission_label');
		$query=$this->db->get(TABLE_PRE.'permission_types');
        if($query->num_rows()>0){
            return $query->result();
        }else{ 
            return false;
        }
	}
	
	/* All Permissions Depending on Label for Admin */
	function get_permission_by_label($permission_label){
		$this->db->where('permission_label',$permission_label);
		$query=$this->db->get(TABLE_PRE.'permission_types');
        if($query->num_rows()>0){
            return $query->result();
        }else{ 
            return false;
        }
	}
	
	/*Add User Permission */
	function add_user_permission($permission){
		$query=$this->db->insert(TABLE_PRE.'user_permission',$permission);
        if($query){
            return true;
        }else{
            return false;
        }
	}
	
	/* Check Admin Status */
	function admin_status($id){
		$this->db->where('admin_id',$id);
		$query = $this->db->get(TABLE_PRE.'admin_details');
		if($query->num_rows()>0){
			return $query->row();
		}else{
			return false;
		}
	}
	
	/* Admin Registration */
	function admin_registration($admin){
        $this->db->where('admin_id',$admin['admin_id']);
        $query=$this->db->update(TABLE_PRE.'admin_details',$admin);
        if($query){
            return true;
        }else{
            return false;
        }
    }
	
	/* Update Login Information */
	function update_login($data){
        $this->db->where('login_id',$data['login_id']);
        $query=$this->db->update(TABLE_PRE.'login',$data);
        if($query){
            return true;
        }else{
            return false;
        }
    }

    /*Add Booking */
    function  add_booking($data){
        $query=$this->db->insert(TABLE_PRE.'bookings',$data);
        if($query){
            return true;
        }else{
            return false;
        }



    }

    /* All Bookings */
    function  all_bookings(){

        $this->db->order_by('cust_from_date','asc');
		
        //$this->db->limit($limit,$start);
        $query=$this->db->get(TABLE_PRE.'bookings');
        if($query->num_rows()>0){
            return $query->result();
        }else{
            return false;
        }
    }
	
	function  all_bookings_report(){

        $this->db->order_by('cust_from_date','asc');
		$this->db->join('hotel_guest', 'hotel_guest.g_id = hotel_bookings.guest_id');
        //$this->db->limit($limit,$start);
        $query=$this->db->get(TABLE_PRE.'bookings');
        if($query->num_rows()>0){
            return $query->result();
        }else{
            return false;
        }
    }



    /* Get Room Id*/
    function get_room_id($hotel_id, $room_no){

        $this->db->where('hotel_id=',$hotel_id);
        $this->db->where('room_no=',$room_no);
        $query=$this->db->get(TABLE_PRE.'room');
        if($query->num_rows()>0){
            return $query->result();
        }else{
            return false;
        }
    }

    /* Get Room Number */

    function get_room_number($room_id){

        $this->db->where('room_id=',$room_id);
        $query=$this->db->get(TABLE_PRE.'room');
        if($query->num_rows()>0){
            return $query->result();
        }else{
            return false;
        }
    }



	
	 /* Add Room */
    function add_room($data){
		$query=$this->db->insert(TABLE_PRE.'room',$data);
        if($query){
            return true;
        }else{
            return false;
        }
	}
	
	/* Number of All Rooms */
	function all_rooms_row(){
		$this->db->where('room_status!=','D');
        $this->db->where('hotel_id=',$this->session->userdata('user_hotel'));
        $query=$this->db->get(TABLE_PRE.'room');
        if($query->num_rows()>0){
            return $query->num_rows();
        }else{
            return false;
        }
    }
    
	/* All Hotels With Pagination */
    function all_rooms(){
		$this->db->where('room_status!=','D');
        $this->db->where('hotel_id=',$this->session->userdata('user_hotel'));
        $this->db->order_by('room_no','asc');
		//$this->db->limit($limit,$start);
        $query=$this->db->get(TABLE_PRE.'room');
        if($query->num_rows()>0){
            return $query->result();
        }else{
            return false;
        }
    }

    /* Get Particular Hotel Information */
    function get_room($room_id){
        $this->db->where('room_id=',$room_id);
        $query=$this->db->get(TABLE_PRE.'room');
        if($query->num_rows()==1){

            return $query->row();
        }else{
            return false;
        }
    }

    /* Update Hotel */
    function update_room($room){

        $this->db->where('room_id=',$room['room_id']);
        $query=$this->db->update(TABLE_PRE.'room',$room);
        if($query){
            return true;
        }else{
            return false;
        }
    }

    function  add_transaction($data){
        $query=$this->db->insert(TABLE_PRE.'transactions',$data);
        if($query){
            return true;
        }else{
            return false;
        }



    }

    function all_transactions(){
        $this->db->order_by('t_id','asc');
        $query=$this->db->get(TABLE_PRE.'transactions');
        if($query->num_rows()>0){
            return $query->result();
        }else{
            return false;
        }
    }
	
	/*function all_transactions_report(){
        $this->db->order_by('t_id','asc');
		join(TABLE_PRE.'guest', 'hotel_guest.g_id = credentials.cid');
        $query=$this->db->get(TABLE_PRE.'transactions');
        if($query->num_rows()>0){
            return $query->result();
        }else{
            return false;
        }
    }*/

    /* Number of All Transactions */
    function all_transactions_row(){
        $query=$this->db->get(TABLE_PRE.'transactions');
        if($query->num_rows()>0){
            return $query->num_rows();
        }else{
            return false;
        }
    }

    /* All Hotels With Transactions */
    function all_transactions_limit(){
        $this->db->order_by('t_id','desc');
        //$this->db->limit($limit,$start);
        $query=$this->db->get(TABLE_PRE.'transactions');
        if($query->num_rows()>0){
            return $query->result();
        }else{
            return false;
        }
    }

    function  add_compliance($data){
        $query=$this->db->insert(TABLE_PRE.'compliance',$data);
        if($query){
			
            return true;
        }else{
			
            return false;
        }



    }

    function all_compliance(){
        $this->db->order_by('c_id','asc');
        $this->db->where('hotel_id=',$this->session->userdata('user_hotel'));
        $query=$this->db->get(TABLE_PRE.'compliance');
        if($query->num_rows()>0){
            return $query->result();
        }else{
            return false;
        }
    }

    /* Number of All Transactions */
    function all_compliance_row(){
        $this->db->where('hotel_id=',$this->session->userdata('user_hotel'));
        $query=$this->db->get(TABLE_PRE.'compliance');
        if($query->num_rows()>0){
            return $query->num_rows();
        }else{
            return false;
        }
    }

    /* All Hotels With Transactions */
    function all_compliance_limit(){
        $this->db->order_by('c_id','desc');
        $this->db->where('hotel_id=',$this->session->userdata('user_hotel'));
        //$this->db->limit($limit,$start);
        $query=$this->db->get(TABLE_PRE.'compliance');
        if($query->num_rows()>0){
            return $query->result();
        }else{
            return false;
        }
    }

    function  add_guest($data){
        $query=$this->db->insert(TABLE_PRE.'guest',$data);
        if($query){
            return true;
        }else{
            return false;
        }



    }

    function  add_broker($data){
        $query=$this->db->insert(TABLE_PRE.'broker',$data);
        if($query){
            return true;
        }else{
            return false;
        }



    }

    function all_broker(){
        $this->db->order_by('b_id','asc');
        $this->db->where('hotel_id=',$this->session->userdata('user_hotel'));
        $query=$this->db->get(TABLE_PRE.'broker');
        if($query->num_rows()>0){
            return $query->result();
        }else{
            return false;
        }
    }

    /* Number of All Transactions */
    function all_broker_row(){
        $this->db->where('hotel_id=',$this->session->userdata('user_hotel'));
        $query=$this->db->get(TABLE_PRE.'broker');
        if($query->num_rows()>0){
            return $query->num_rows();
        }else{
            return false;
        }
    }

    /* All Hotels With Transactions */
    function all_broker_limit(){
        $this->db->order_by('b_id','desc');
        $this->db->where('hotel_id=',$this->session->userdata('user_hotel'));
        //$this->db->limit($limit,$start);
        $query=$this->db->get(TABLE_PRE.'broker');
        if($query->num_rows()>0){
            return $query->result();
        }else{
            return false;
        }
    }

    function all_guest(){
        $this->db->order_by('g_id','asc');
        $this->db->where('hotel_id=',$this->session->userdata('user_hotel'));
        $query=$this->db->get(TABLE_PRE.'guest');
        if($query->num_rows()>0){
            return $query->result();
        }else{
            return false;
        }
    }

    /* Number of All Transactions */
    function all_guest_row(){
        $this->db->where('hotel_id=',$this->session->userdata('user_hotel'));
        $query=$this->db->get(TABLE_PRE.'guest');
        if($query->num_rows()>0){
            return $query->num_rows();
        }else{
            return false;
        }
    }

    /* All Hotels With Transactions */
    function all_guest_limit()
    {
        //$this->db->order_by('g_id','desc');
        //$this->db->where('hotel_id=',$this->session->userdata('user_hotel'));
        //$this->db->limit($limit,$start);
		$today = date('Y-m-d');
		$this->db->where('cust_from_date',$today);
        $this->db->where('hotel_id',$this->session->userdata('user_hotel'));
		$this->db->select_sum('no_of_guest');
		$query = $this->db->get(TABLE_PRE.'bookings');
        if($query->num_rows()>0){
            return $query->result();
        }else{
            return false;
        }

        /*$this->db->select_sum('age');
        $this->db->where('hotel_id=',$this->session->userdata('user_hotel'));
        $this->db->where($date,'');*/
    }
	
	/* 18.11.2015 */
	
	function all_guest_limit_view()
    {
        $this->db->order_by('g_id','desc');
        $this->db->where('hotel_id=',$this->session->userdata('user_hotel'));
        //$this->db->limit($limit,$start);
        $query=$this->db->get(TABLE_PRE.'guest');
        if($query->num_rows()>0){
            return $query->result();
        }else{
            return false;
        }

        /*$this->db->select_sum('age');
        $this->db->where('hotel_id=',$this->session->userdata('user_hotel'));
        $this->db->where($date,'');*/
    }
	
	function get_guest_details($g_id_edit)
	{
		//echo "In Model";
		//echo  $g_id_edit;
		//exit();
		$this->db->select('*');
        $this->db->where('g_id=',$g_id_edit);
        //$this->db->limit($limit,$start);
        $query=$this->db->get(TABLE_PRE.'guest');
        if($query->num_rows()>0){
            return $query->result();
        }else{
            return false;
        }
	}
	
	function get_broker_details($b_id_edit)
	{
		//echo "In Model";
		//echo  $b_id_edit;
		//exit();
		$this->db->select('*');
        $this->db->where('b_id=',$b_id_edit);
        //$this->db->limit($limit,$start);
        $query=$this->db->get(TABLE_PRE.'broker');
        if($query->num_rows()>0){
            return $query->result();
        }else{
            return false;
        }
	}
	
	
	function edit_guest($guest_edit,$g_id)
	{
		$this->db->where('g_id', $g_id);
		$query = $this->db->update(TABLE_PRE.'guest', $guest_edit);
		//echo  $this->db->last_query();
		if($query){
			return true;
		}else{
			return false;
		}
		
	}
	
	function edit_broker($broker_edit,$b_id)
	{
		//echo "In model".$b_id;
		//print_r($broker_edit);
		//exit();
		$this->db->where('b_id', $b_id);
		$query = $this->db->update(TABLE_PRE.'broker', $broker_edit);
		//echo  $this->db->last_query();
		if($query){
			return true;
		}else{
			return false;
		}
	}
	
	function all_booking_id()
	{
		$this->db->select('booking_id');
		//$this->db->from(TABLE_PRE.'bookings');
		$this->db->where('hotel_id',$this->session->userdata('user_hotel'));
		$query = $this->db->get(TABLE_PRE.'bookings');
		if($query->num_rows() > 0){
   			foreach($query->result_array() as $row){
    		$data[] = $row;
   			}
   			return $data;
  		}
		else
		{
			return false;
		}
	}
	
	/* 18.11.2015 */
	/* 19.11.2015*/
	function all_t_amount($val)
	{
		/*$agr = array(
			'hotel_id' => $this->session->userdata('user_hotel'),
			'booking_id'=> $val);
		$this->db->select('*');
		$this->db->where($agr);
		$query = $this->db->get(TABLE_PRE.'bookings');
		if($query->num_rows() > 0){
   			foreach($query->result_array() as $row){
    		$data[] = $row;
   			}
   			return $data;
  		}
		else
		{
			return false;
		}*/
		
		$this->db->select('base_room_rent,rent_mode_type,mod_room_rent');
		$this->db->from('hotel_bookings');
		$this->db->where('booking_id',$val);
		
		$query = $this->db->get();
		if($query->num_rows() > 0){
   			/*foreach($query->result_array() as $row1){
    		//$data1[] = $row1;
   			}
   			return $data1;*/
			return $query->result();
  		}
		else
		{
			return false;
		}
	}
	/*19.11.2015*/
	
	function  all_bookings_unique(){


        /*$this->db->distinct();

        $this->db->select('room_id');

        $this->db->order_by('cust_from_date','asc');
        //$this->db->limit($limit,$start);
        $query=$this->db->get(TABLE_PRE.'bookings');
        if($query->num_rows()>0){
            return $query->result();
        }else{
            return false;
        } 4.12.2015 by sandip */ 
        /*$time = date('Y-m-d');
        $arr = array('t_date'=>$time);
        $this->db->select_sum('t_amount');
        $this->db->from(TABLE_PRE.'transactions');
        $this->db->where($arr);
        $query = $this->db->get();
        
        if($query)
        {
            return $query->result();
        }
        else
        {
            return false;
        }*/
		//$this->db->where('t_booking_id',$booking_id);
		//$time = date('Y-m-d');
		//$this->db->where(DATE_FORMAT('t_date',"%Y-%m-%d"),$time);
        $date = date("Y-m-d");

		$this->db->select_sum('t_amount');
        //$this->db->from(TABLE_PRE.'transactions');
		//$query = $this->db->get_where(TABLE_PRE.'transactions',array('t_date' => $date));
        $this->db->like('t_date', $date, 'after'); 
        $query = $this->db->get('hotel_transactions');
        //$str = $this->db->last_query();
        //echo $str;
        //exit();
		if($query->num_rows()>0)
        {
			return $query->result();	 
        }
		else
        {
            return false;
		}
    }


 function report_search($visit,$room_id, $date_1,$date_2){


        $this->db->like('nature_visit',$visit);
        $this->db->like('room_id',$room_id);

//     $sql = "SELECT * FROM ".TABLE_PRE."bookings WHERE  ( ((cust_end_date <= '".$date_2."') AND (cust_from_date >= '".$date_1."')) OR (nature_visit LIKE '%".$visit."%') OR  (room_id LIKE '".$room_id."') ) ";



if($date_1  && $date_2)

{
    if($date_2=="1970-01-01")
    {
        $date_2="3000-01-01";


    }

    $this->db->where('cust_from_date >=', $date_1);
    $this->db->where('cust_end_date <=', $date_2);

}
       // $this->db->limit($limit,$start);
        $query=$this->db->get(TABLE_PRE.'bookings');




        if($query->num_rows()>0){
            return $query->result();
        }else{
            return false;
        }



    }


function fetch_all_address($pincode)
{
        $this->db->distinct();
        $this->db->select('area_0,area_1,area_4');
        $this->db->from('hotel_area_code');
        $this->db->where('pincode',$pincode);
        $query=$this->db->get();

        if($query->num_rows() >0)
        {
            return $query->result();
        }
        else
        {
            return false;
        }
}
function all_f_reports(){
        $this->db->order_by('t_booking_id','desc');
        $this->db->like('t_date',date("Y-m-d"));
        //$this->db->limit($limit,$start);
        $query=$this->db->get(TABLE_PRE.'transactions');
        if($query->num_rows()>0){
            return $query->result();
        }else{
            return false;
        }
    }
	
		function add_booking_transaction($t_transaction){
				//echo "In Model";
				//print_r($t_transaction);
				//exit();
				$query=$this->db->insert(TABLE_PRE.'transactions',$t_transaction);
				$sql = $this->db->last_query();
				//echo $sql;
				//exit();
        		if($query){
            			return true;
        		}else{
            			return false;
        		}
		}
		
		function get_data_for_excel()
		{
			$this->db->select('booking_id,cust_name,room_id,cust_from_date,cust_end_date,cust_contact_no,mod_room_rent,nature_visit');
        	$this->db->from(TABLE_PRE.'bookings');
        	$query=$this->db->get();

        	if($query->num_rows() >0){
            	return $query->result();
        	}
        	else{
            	return false;
        	}
		}
		
		function update_checkout_status($booking_id)
		{
			$data = array(
               'booking_status_id' => '6'
               );
			 $this->db->where('booking_id', $booking_id);
			 $query=$this->db->update(TABLE_PRE.'bookings',$data);
			 if($query)
			 {
				 return true;
			 }
			 else{
				 return false;
			 }
		}
		
		function guest_check($id){
			
			$query=$this->db->where(TABLE_PRE.'guest',$id);
        if($query->num_rows()==1){
            return true;
        }else{ 
            return false;
        }
		}

}



?>