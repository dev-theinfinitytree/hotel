
<div class="brdr-box">

        <label style="font-weight:normal;" >Name :</label>   <label style="font-weight:normal;" ><?php ?> </label>
        <label style="font-weight:normal; margin-left:105px; " >Address :</label>  <label style="font-weight:normal;" ><?php ?></label><br><label style="font-weight:normal;" >Mobile No :</label><label style="font-weight:normal;" ><?php ?></label>
        <label style="font-weight:normal;margin-left:88px;" >Occupation :</label>  <label style="font-weight:normal;" ><?php ?></label><br><label style="font-weight:normal;" >Last date :</label><label style="font-weight:normal;" ><?php ?></label>
        <label style="font-weight:normal;margin-left:90px;" >Last Room :</label>  <label style="font-weight:normal;" ><?php ?></label>
                                                            
</div>