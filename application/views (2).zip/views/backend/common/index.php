<?php
$this->load->view('backend/common/header');
$this->load->view('backend/common/header_menu');
$this->load->view('backend/common/side_menu');
$this->load->view('backend/common/customizer');
$this->load->view($page);
$this->load->view('backend/common/quick_sidebar');
$this->load->view('backend/common/footer_text');
$this->load->view('backend/common/footer');
?>
<!--<script type = "text/javascript" > $(document).keydown(function(e) { var element = e.target.nodeName.toLowerCase(); if (e.keyCode === 8) { return false; } }); </script>-->