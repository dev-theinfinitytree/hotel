<!-- BEGIN FOOTER -->
<div class="page-footer">
	<div class="page-footer-inner">
		 <?php echo date('Y');?> &copy; The Infinity Tree <a href="http://www.theinfinitytree.com/ title="Purchase this hotel software" target="_blank">Purchase Hotel Objects!</a>
	</div>
	<div class="scroll-to-top">
		<i class="icon-arrow-up"></i>
	</div>
</div>
<!-- END FOOTER -->