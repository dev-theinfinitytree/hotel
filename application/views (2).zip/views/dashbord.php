    <section class="container main-table-box">
        <div class="container">
            <?php echo (isset($output))?$output:''; ?>
            
        </div>
    </section>