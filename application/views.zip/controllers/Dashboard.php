<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller
{

    function __construct()
    {
        /* Session Checking Start*/
        parent::__construct();
        if (!$this->session->userdata('is_logged_in')) {
            redirect('login');
        }
        /* Session Checking End*/

        /* URL Value Encryption Start */
        function base64url_encode($data)
        {
            return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
        }

        /* URL Value Encryption End */

        /* URL Value Decryption Start */
        function base64url_decode($data)
        {
            return base64_decode(str_pad(strtr($data, '-_', '+/'), strlen($data) % 4, '=', STR_PAD_RIGHT));
        }
        /* URL Value Decryption End */
    }

    /* Dashboard Page Start */
   function index()
    {

        $id = $this->session->userdata('user_id');
        $data['admin_status'] = $this->dashboard_model->admin_status($id);
       /* if ($data['admin_status']->admin_status == 'I') {
            $data['country'] = $this->dashboard_model->get_country();
            $data['heading'] = 'Complete Your Registration';
            $data['description'] = 'You have to complete your registration to perform operations.';
            $data['active'] = 'dashboard';
            $data['page'] = 'backend/dashboard/admin_registration';
            $this->load->view('backend/common/admin_index', $data);
        } else {*/


            $data['heading'] = "Dashboard";
            $data['description'] = 'Welcome '.$this->session->userdata('user_name').' to Hotel Objects Dashboard';
            $data['active'] = 'dashboard';
            $data['page'] = 'backend/dashboard/index';
            $data['bookings'] = $this->dashboard_model->all_bookings();
			$data['hotel_name'] = $this->dashboard_model->get_hotel($this->session->userdata('user_hotel'));
            $data['unique_room_bookings'] = $this->dashboard_model->all_bookings_unique();
            //echo "<pre>";
            //print_r($data);
            //echo $data['unique_room_bookings'];
            //exit();
            $data['all_rooms'] = $this->dashboard_model->all_rooms();
            $data['guests'] =$this->dashboard_model->all_guest_limit_view();
            $this->load->view('backend/common/index', $data);
        //}

    }





    /* Dashboard Page End */

    /* Logout Start */
    function logout()
    {
        $this->session->sess_destroy();
        redirect('login/logged_out');
    }
    /* Logout End */

    /* Add Admin Start */
    function add_admin()
    {
        if($this->session->userdata('admin') =='1') {
            $data['heading'] = 'Admin';
            $data['sub_heading'] = 'Add Admin';
            $data['description'] = 'Add Admin Here';
            $data['active'] = 'add_admin';
            $data['hotel'] = $this->dashboard_model->all_hotel_list();
			$data['hotel_name'] = $this->dashboard_model->get_hotel($this->session->userdata('user_hotel'));
            $permission_users = '2';
            $data['permission'] = $this->dashboard_model->admin_permission_label($permission_users);
            if ($this->input->post()) {
                $table = TABLE_PRE . 'admin_details';
                $table1 = TABLE_PRE . 'login';
                $this->form_validation->set_rules('admin_hotel', 'Hotel Name', 'trim|required|xss_clean');
                $this->form_validation->set_rules('admin_first_name', 'First Name', 'trim|required|xss_clean');

                $this->form_validation->set_rules('admin_middle_name', 'Middle Name', 'trim|xss_clean');
                $this->form_validation->set_rules('admin_last_name', 'Last Name', 'trim|required|xss_clean');
                $this->form_validation->set_rules('admin_email', 'Email Address', 'trim|required|valid_email|xss_clean|is_unique[' . $table . '.admin_email]');
                $this->form_validation->set_rules('admin_username', 'Username', 'trim|required|xss_clean|min_length[5]|max_length[20]|is_unique[' . $table1 . '.user_name]');
                $this->form_validation->set_rules('admin_password', 'Password', 'trim|required|xss_clean|min_length[5]|max_length[50]');
                $this->form_validation->set_rules('admin_retype_password', 'Retype Password', 'trim|required|xss_clean|min_length[5]|max_length[50]|matches[admin_password]');
                $this->form_validation->set_rules('permission[]', 'Permission', 'required');

                    date_default_timezone_set("Asia/Kolkata");
                    if($this->session->userdata('user_type_slug') == "SUPA"){
                        $admin_hotel=$this->input->post('admin_hotel');
                    }
                    else{

                        $admin_hotel=$this->session->userdata('user_hotel');
                    }

                if($this->session->userdata('user_type_slug')=="SUPA"){
                    $type1=2;
                }
                elseif($this->session->userdata('user_type_slug')=="AD"){
                    $type1=3;
                }
                    $admin = array(
                        'admin_hotel' => $admin_hotel,
                        'admin_first_name' => $this->input->post('admin_first_name'),
                        'admin_middle_name' => $this->input->post('admin_middle_name'),
                        'admin_last_name' => $this->input->post('admin_last_name'),
                        'admin_email' => $this->input->post('admin_email'),
                        'admin_user_type' => $type1,
                        'admin_create_date' => date("Y-m-d H:i:s"),
                        'admin_modification_date' => date("Y-m-d H:i:s")
                    );
                    $query1 = $this->dashboard_model->add_admin($admin);

                if($this->session->userdata(user_type_slug)=="SUPA"){
                    $type=2;
                }
                elseif($this->session->userdata(user_type_slug)=="AD"){
                    $type=3;
                }

                    if (isset($query1) && $query1) {
                        $user = array(
                            'user_id' => $query1,
                            'hotel_id' => $admin_hotel,
                            'user_name' => $this->input->post('admin_username'),
                            'user_password' => sha1(md5($this->input->post('admin_password'))),
                            'user_email' => $this->input->post('admin_email'),
                            'user_type_id' => $type,
                            'user_status' => 'A'
                        );
                        $query2 = $this->dashboard_model->add_user($user);

                        $hotel = array(
                            'hotel_id' => $this->input->post('admin_hotel'),
                            'hotel_status' => 'A'
                        );
                        $update = $this->dashboard_model->update_hotel($hotel);

                        $permission_id = implode(",", $this->input->post('permission'));
                        if($this->session->userdata(user_type_slug)=="SUPA"){
                            $type3="AD";
                        }
                        elseif($this->session->userdata(user_type_slug)=="AD"){
                            $type3="SUB";
                        }
                        $permission = array(
                            'user_id' => $query1,
                            'user_type' => $type3,
                            'user_permission_type' => $permission_id
                        );
                        $user_permission = $this->dashboard_model->add_user_permission($permission);
                    }

                    if (isset($query2) && $query2) {
                        $this->session->set_flashdata('succ_msg', "Admin Added Successfully!");
                        $msg =
                            "<p>Hello</p>
							<p>You are registered with Hotel Objects. Please click here to activate your account:-" . base_url() . "login/activate_admin/" . base64url_encode($query2) . "</p>
							<p>Username:" . $this->input->post('admin_username') . "</p>
							<p>Password:" . $this->input->post('admin_password') . "</p>
							<p>--Hotel Object Team</p>";
                        $config['protocol'] = 'smtp';
                        $config['smtp_host'] = 'smtp.webartmedialabs.com';
                        $config['mailtype'] = 'html';
                        $this->email->initialize($config);
                        $this->email->from('sayak@webartmedialabs.com', 'Hotel Objects');
                        $this->email->to($this->input->post('admin_email'), $this->input->post('admin_first_name'));
                        $this->email->subject('Registering With Hotel Objects');
                        $this->email->message($msg);
                        if ($this->email->send()) {
                            redirect('dashboard/add_admin');
                        } else {
                            $this->session->set_flashdata('err_msg', $this->email->print_debugger());
                            redirect('dashboard/add_admin');
                        }
                        redirect('dashboard/add_admin');
                    } else {
                        $this->session->set_flashdata('err_msg', "Database Error. Try again later!");
                        redirect('dashboard/add_admin');
                    }

            } else {
                $data['page'] = 'backend/dashboard/add_admin';
                $this->load->view('backend/common/index', $data);
            }
        } else {
            redirect('dashboard');
        }
    }
    /* Add Admin End */

    /* Ajax Username Checking During User Addition Start */
    function username_check()
    {
        $username['user_name'] = $this->input->post('username');
        $query = $this->dashboard_model->username_check($username);
        if (isset($query) && $query) {
            die('<img src=' . base_url() . 'assets/dashboard/images/dislike-icon.png style="height:40px;">');
        } else {
            die('<img src=' . base_url() . 'assets/dashboard/images/like-icon.png style="height:40px;">');
        }
    }
    /* Ajax Username Checking During User Addition End */

    /* Ajax Email Checking During User Addition Start */
    function email_check()
    {
        $email['user_email'] = $this->input->post('email');
        $query = $this->dashboard_model->email_check($email);
        if (isset($query) && $query) {
            die('<img src=' . base_url() . 'assets/dashboard/images/dislike-icon.png style="height:40px;">');
        } else {
            die('<img src=' . base_url() . 'assets/dashboard/images/like-icon.png style="height:40px;">');
        }
    }
    /* Ajax Email Checking During User Addition End */

    /* Ajax Email Checking During Admin Registration Start */
    function admin_email_check()
    {
        $email['user_email'] = $this->input->post('email');
        if ($this->input->post('email') == $this->input->post('hemail')) {
            die('<img src=' . base_url() . 'assets/dashboard/images/like-icon.png style="height:40px;">');
        } else {
            $query = $this->dashboard_model->email_check($email);
            if (isset($query) && $query) {
                die('<img src=' . base_url() . 'assets/dashboard/images/dislike-icon.png style="height:40px;">');
            } else {
                die('<img src=' . base_url() . 'assets/dashboard/images/like-icon.png style="height:40px;">');
            }
        }
    }
    /* Ajax Email Checking During Admin Registration End */

    /* Admin Registration Start */
    function admin_registration()
    {
        if($this->session->userdata('admin') =='1') {
            $table = TABLE_PRE . 'login';
            $this->form_validation->set_rules('admin_first_name', 'First Name', 'trim|required|xss_clean');
            $this->form_validation->set_rules('admin_first_name', 'Middle Name', 'trim|xss_clean');
            $this->form_validation->set_rules('admin_last_name', 'Last Name', 'trim|required|xss_clean');
            $this->form_validation->set_rules('admin_address', 'Address', 'trim|required|xss_clean');
            $this->form_validation->set_rules('admin_city', 'City', 'trim|required|xss_clean');
            $this->form_validation->set_rules('admin_district', 'District', 'trim|required|xss_clean');
            $this->form_validation->set_rules('admin_state', 'State', 'trim|required|xss_clean');
            $this->form_validation->set_rules('admin_country', 'Country', 'trim|required|xss_clean');
            $this->form_validation->set_rules('admin_pin', 'Pin', 'trim|required|xss_clean');
            if ($this->input->post('admin_email') == $this->input->post('admin_email_hidden')) {
                $this->form_validation->set_rules('admin_email', 'Email Address', 'trim|required|valid_email|xss_clean');
            } else {
                $this->form_validation->set_rules('admin_email', 'Email Address', 'trim|required|valid_email|xss_clean|is_unique[' . $table . '.user_email]');
            }
            $this->form_validation->set_rules('admin_phone1', 'Phone Number', 'trim|required|numeric|max_length[10]|xss_clean');
            $this->form_validation->set_rules('admin_phone2', 'Alternative Phone Number', 'trim|numeric|max_length[10]|xss_clean');
            $this->form_validation->set_rules('admin_dob', 'Date of Birth', 'trim|required|xss_clean');
            $this->form_validation->set_rules('admin_mother_tongue', 'Mother Tongue', 'trim|required|xss_clean');
            $this->form_validation->set_rules('admin_comm_language', 'Mother Tongue', 'trim|required|xss_clean');
            $this->form_validation->set_rules('admin_idproof1_type', 'ID Proof 1', 'trim|xss_clean');
            $this->form_validation->set_rules('admin_idproof2_type', 'ID Proof 2', 'trim|xss_clean');
            $this->form_validation->set_rules('admin_idproof3_type', 'ID Proof 3', 'trim|xss_clean');

            $admin_idproof1_path = $admin_idproof2_path = $admin_idproof3_path = '';

            $this->upload->initialize($this->set_upload_options());

            if ($this->input->post('admin_idproof1_type')) {
                if ($this->upload->do_upload('userdata1')) {
                    $admin_idproof1_path = $this->upload->data('file_name');
                } else {
                    $this->session->set_flashdata('err_msg', $this->upload->display_errors());
                    redirect('dashboard');
                }
            }

            if ($this->input->post('admin_idproof2_type')) {
                if ($this->upload->do_upload('userdata2')) {
                    $admin_idproof2_path = $this->upload->data('file_name');
                } else {
                    $this->session->set_flashdata('err_msg', $this->upload->display_errors());
                    redirect('dashboard');
                }
            }

            if ($this->input->post('admin_idproof3_type')) {
                if ($this->upload->do_upload('userdata3')) {
                    $admin_idproof3_path = $this->upload->data('file_name');
                } else {
                    $this->session->set_flashdata('err_msg', $this->upload->display_errors());
                    redirect('dashboard');
                }
            }

            if ($this->upload->do_upload('image')) {
                $admin_image = $this->upload->data('file_name');
            } else {
                $admin_image = "user.png";
            }

            date_default_timezone_set("Asia/Kolkata");

            $var = $this->input->post('admin_dob');
            if (strpos(".", $var)) {
                $date = str_replace('.', '-', $var);
            } else {
                if (strpos("/", $var)) {
                    $date = str_replace('/', '-', $var);
                } else {
                    $date = $var;
                }
            }
            $date = date('Y-m-d', strtotime($date));

            $admin = array(
                'admin_id' => $this->session->userdata('user_id'),
                'admin_first_name' => $this->input->post('admin_first_name'),
                'admin_middle_name' => $this->input->post('admin_middle_name'),
                'admin_last_name' => $this->input->post('admin_last_name'),
                'admin_email' => $this->input->post('admin_email'),
                'admin_address' => $this->input->post('admin_address'),
                'admin_city' => $this->input->post('admin_city'),
                'admin_district' => $this->input->post('admin_district'),
                'admin_state' => $this->input->post('admin_state'),
                'admin_country' => $this->input->post('admin_country'),
                'admin_pin' => $this->input->post('admin_pin'),
                'admin_phone1' => $this->input->post('admin_phone1'),
                'admin_phone2' => $this->input->post('admin_phone2'),
                'admin_dob' => $date,
                'admin_mother_tongue' => $this->input->post('admin_mother_tongue'),
                'admin_comm_language' => $this->input->post('admin_comm_language'),
                'admin_idproof1_type' => $this->input->post('admin_idproof1_type'),
                'admin_idproof1_path' => $admin_idproof1_path,
                'admin_idproof2_type' => $this->input->post('admin_idproof2_type'),
                'admin_idproof2_path' => $admin_idproof2_path,
                'admin_idproof3_type' => $this->input->post('admin_idproof3_type'),
                'admin_idproof3_path' => $admin_idproof3_path,
                'admin_image' => $admin_image,
                'admin_modification_date' => date("Y-m-d H:i:s"),
                'admin_status' => 'A'
            );

            if ($this->form_validation->run() == FALSE) {
                $this->session->set_flashdata('err_msg', validation_errors());
                redirect('dashboard');
            } else {
                $update = $this->dashboard_model->admin_registration($admin);
                $login_data = array(
                    'login_id' => $this->session->userdata('login_id'),
                    'user_email' => $this->input->post('admin_email')
                );
                $login = $this->dashboard_model->update_login($login_data);
                if (isset($update) && $update && isset($login) && $login) {
                    $this->session->set_flashdata('succ_msg', "Your registration completed successfully.");
                } else {
                    $this->session->set_flashdata('err_msg', "Your registration is incomplete. Try again!");
                }
                redirect('dashboard');
            }
        } else {
            redirect('dashboard');
        }
    }
    /* Admin Registration End */

    /* Add Hotel Start */
    function add_hotel_m()
    {
        if($this->session->userdata('hotel_m') =='1') {
            $data['heading'] = 'Hotel Management';
            $data['sub_heading'] = 'Add Hotel Management';
            $data['description'] = 'Add Hotel Here';
            $data['active'] = 'add_hotel_m';
			$data['hotel_name'] = $this->dashboard_model->get_hotel($this->session->userdata('user_hotel'));
            if ($this->input->post()) {
					
					$hotel_type = $this->input->post('hotel_type');
					$hotel_type_string = "";
					$hotel_type_string =  $hotel_type_string.implode(',' , $hotel_type);
					$guest_option = $this->input->post('guest');
					$guest_option_string = "";
					$guest_option_string =$guest_option_string . implode(',' , $guest_option);
					
					$broker_option = $this->input->post('broker');
					$broker_option_string = "";
					$broker_option_string = $broker_option_string . implode(',' , $broker_option);  
					/*Start Logo Upload*/
					
					$this->upload->initialize($this->set_upload_options());
					if ($this->upload->do_upload('image_photo') ) {
							//echo "uploaded"; exit();
							$hotel_logo = $this->upload->data('file_name');
							$filename = $hotel_logo;
                        	$source_path = './upload/' . $filename;
                        	$target_path = './upload/hotel/';
                        	
							$config_manip = array(
                            'image_library' => 'gd2',
                            'source_image' => $source_path,
                            'new_image' => $target_path,
                            'maintain_ratio' => TRUE,
                            'create_thumb' => TRUE,
                            'thumb_marker' => '_thumb',
                            'width' => 100,
                            'height' => 100
                        	);
                        	$this->load->library('image_lib', $config_manip);
							
							if (!$this->image_lib->resize()) {
                            		$this->session->set_flashdata('err_msg', $this->image_lib->display_errors());
                            		redirect('dashboard/add_hotel_m');
                        	}
                        		// clear //
                        			$thumb_name = explode(".", $filename);
                        			$logo_thumb = $thumb_name[0] . $config_manip['thumb_marker'] . "." . $thumb_name[1];
                        			$this->image_lib->clear();
					}
					else{
						redirect('dashboard/add_hotel_m');
					}
					/*End Logo Upload*/
					//exit();
                    date_default_timezone_set("Asia/Kolkata");
                    $hotel = array(
                        'hotel_name' => $this->input->post('hotel_name'),
						'hotel_year_established' => $this->input->post('hotel_year_established'),
						'hotel_ownership_type' => $this->input->post('hotel_ownership_type'),
						'hotel_type' => $hotel_type_string,
						'hotel_rooms' => $this->input->post('hotel_rooms'),
						'hotel_logo_images' => $hotel_logo,
						'hotel_logo_images_thumb' => $logo_thumb ,
						'hotel_logo_text' => $this->input->post('images_text'),
						'hotel_status' => 'A'
                    );
					
					$hotel_contact_details = array(
						'hotel_street1' => $this->input->post('hotel_street1'),
						'hotel_street2' => $this->input->post('hotel_street2'),
						'hotel_landmark' => $this->input->post('hotel_landmark'),
						'hotel_district' => $this->input->post('hotel_district'),
						'hotel_pincode' => $this->input->post('hotel_pincode'),
						'hotel_state'=> $this->input->post('hotel_state'),
						'hotel_country' => $this->input->post('hotel_country'),
						'hotel_branch_street1' => $this->input->post('hotel_branch_street1'),
						'hotel_branch_street2' => $this->input->post('hotel_branch_street2'),
						'hotel_branch_landmark' => $this->input->post('hotel_branch_landmark'),
						'hotel_branch_district' => $this->input->post('hotel_branch_district'),
						'hotel_branch_pincode' => $this->input->post('hotel_branch_pincode'),
						'hotel_branch_state' => $this->input->post('hotel_branch_state'),
						'hotel_branch_country' => $this->input->post('hotel_branch_country'),
						'hotel_booking_street1' => $this->input->post('hotel_booking_street1'),
						'hotel_booking_street2' => $this->input->post('hotel_booking_street2'),
						'hotel_booking_landmark' => $this->input->post('hotel_booking_landmark'),
						'hotel_booking_district' => $this->input->post('hotel_booking_district'),
						'hotel_booking_pincode' => $this->input->post('hotel_booking_pincode'),
						'hotel_booking_state' => $this->input->post('hotel_booking_state'),
						'hotel_booking_country' => $this->input->post('hotel_booking_country'),
						'hotel_frontdesk_name' => $this->input->post('hotel_frontdesk_name'),
						'hotel_frontdesk_mobile' => $this->input->post('hotel_frontdesk_mobile'),
						'hotel_frontdesk_mobile_alternative' => $this->input->post('hotel_frontdesk_mobile_alternative'),
						'hotel_frontdesk_email' => $this->input->post('hotel_frontdesk_email'),
						'hotel_owner_name' => $this->input->post('hotel_owner_name'),
						'hotel_owner_mobile' => $this->input->post('hotel_owner_mobile'),
						'hotel_owner_mobile_alternative' => $this->input->post('hotel_owner_mobile_alternative'),
						'hotel_owner_email' => $this->input->post('hotel_owner_email'),
						'hotel_hr_name' => $this->input->post('hotel_hr_name'),
						'hotel_hr_mobile' => $this->input->post('hotel_hr_mobile'),
						'hotel_hr_mobile_alternative' => $this->input->post('hotel_hr_mobile_alternative'),
						'hotel_hr_email' => $this->input->post('hotel_hr_email'),
						'hotel_accounts_name' => $this->input->post('hotel_accounts_name'),
						'hotel_accounts_mobile' => $this->input->post('hotel_accounts_mobile'),
						'hotel_accounts_mobile_alternative' => $this->input->post('hotel_accounts_mobile_alternative'),
						'hotel_accounts_email' => $this->input->post('hotel_accounts_email'),
						'hotel_near_police_name' => $this->input->post('hotel_near_police_name'),
						'hotel_near_police_mobile' => $this->input->post('hotel_near_police_mobile'),
						'hotel_near_police_mobile_alternative' => $this->input->post('hotel_near_police_mobile_alternative'),
						'hotel_near_police_email' => $this->input->post('hotel_near_police_email'),
						'hotel_near_medical_name' => $this->input->post('hotel_near_medical_name'),
						'hotel_near_medical_mobile' => $this->input->post('hotel_near_medical_mobile'),
						'hotel_near_medical_mobile_alternative' => $this->input->post('hotel_near_medical_mobile_alternative'),
						'hotel_near_medical_email' => $this->input->post('hotel_near_medical_email'),
						'hotel_fax' => $this->input->post('hotel_fax'),
						'hotel_website' => $this->input->post('hotel_website'),
						'hotel_working_from' => '',
						'hotel_working_upto' => ''
					);
					
					$hotel_tax_details = array(
						'hotel_tax_applied' => $this->input->post('hotel_tax_applied'),
						'hotel_service_tax' => $this->input->post('hotel_service_tax'),
						'hotel_luxury_tax' => $this->input->post('hotel_luxury_tax'),
						'hotel_service_charge' =>$this->input->post('hotel_service_charge'),
						'hotel_stander_tac' => $this->input->post('hotel_stander_tac')
					);
					
					$hotel_billing_settings = array(
						'billing_name' => $this->input->post('billing_name'),
						'billing_street1' => $this->input->post('billing_street1'),
						'billing_street2' => $this->input->post('billing_street2'),
						'billing_landmark' => $this->input->post('billing_landmark'),
						'billing_district' => $this->input->post('billing_district'),
						'billing_pincode' => $this->input->post('billing_pincode'),
						'billing_state' => $this->input->post('billing_state'),
						'billing_country' => $this->input->post('billing_country'),
						'billing_email' => $this->input->post('billing_email'),
						'billing_phone' => $this->input->post('billing_phone'),
						'billing_fax' => $this->input->post('billing_fax'),
						'billing_vat' => $this->input->post('billing_vat'),
						'billing_bank_name' => $this->input->post('billing_bank_name'),
						'billing_account_no'=> $this->input->post('billing_account_no'),
						'billing_ifsc_code' => $this->input->post('billing_ifsc_code')
						
						
					);
					$hotel_general_preference = array(
					
						'hotel_check_in_time_hr' => $this->input->post('hotel_check_in_time_hr'),
						'hotel_check_in_time_mm' => $this->input->post('hotel_check_in_time_mm'),
						'hotel_check_in_time_fr' => $this->input->post('hotel_check_in_time_fr'),
						'hotel_check_out_time_hr' => $this->input->post('hotel_check_out_time_hr'),
						'hotel_check_out_time_mm' => $this->input->post('hotel_check_out_time_mm'),
						'hotel_check_out_time_fr' => $this->input->post('hotel_check_out_time_fr'),
						'hotel_guest' => $guest_option_string,
						'hotel_broker'=> $broker_option_string,
						'hotel_broker_commission' => 0,
						'hotel_date_format' => $this->input->post('hotel_date_format'),
						'hotel_time_format' => $this->input->post('hotel_time_format')
					);
					
                    $query = $this->dashboard_model->add_hotel($hotel,$hotel_contact_details,$hotel_tax_details,$hotel_billing_settings,$hotel_general_preference);
                	if($query){
                    	$data['page'] = 'backend/dashboard/add_hotel_m';
                    	$this->load->view('backend/common/index', $data);
					}
                	else{
                    	echo "php error";
					}


            } else {
                $data['country'] = $this->dashboard_model->get_country();
                $data['star'] = $this->dashboard_model->get_star_rating();
                $data['page'] = 'backend/dashboard/add_hotel_m';
                $this->load->view('backend/common/index', $data);
            }
        } else {
            redirect('dashboard');
        }
    }
    /* Add Hotel End */

    /* Ajax Email Checking During Hotel Addition Start */
    function hotel_email_check()
    {
        if($this->session->userdata('admin') =='1') {
            $email['hotel_email'] = $this->input->post('email');
            $query = $this->dashboard_model->hotel_email_check($email);
            if (isset($query) && $query) {
                die('<img src=' . base_url() . 'assets/dashboard/images/dislike-icon.png style="height:40px;">');
            } else {
                die('<img src=' . base_url() . 'assets/dashboard/images/like-icon.png style="height:40px;">');
            }
        } else {
            redirect('dashboard');
        }
    }
    /* Ajax Email Checking During Hotel Addition End */

    /* Ajax Phone No. Checking During Hotel Addition Start */
    function hotel_phone_check()
    {
        if($this->session->userdata('admin') =='1') {
            $phone['hotel_phone'] = $this->input->post('phone');
            $query = $this->dashboard_model->hotel_phone_check($phone);
            if (isset($query) && $query) {
                die('<img src=' . base_url() . 'assets/dashboard/images/dislike-icon.png style="height:40px;">');
            } else {
                die('<img src=' . base_url() . 'assets/dashboard/images/like-icon.png style="height:40px;">');
            }
        } else {
            redirect('dashboard');
        }
    }
    /* Ajax Phone No. Checking During Hotel Addition End */

    /* All Hotel Start */
    function all_hotel_m()
    {
        if($this->session->userdata('hotel_m') =='1') {
            $data['heading'] = 'Hotel Management';
            $data['sub_heading'] = 'All Hotels';
            $data['description'] = 'Added Hotel List';
            $data['active'] = 'all_hotel_m';
			$data['hotel_name'] = $this->dashboard_model->get_hotel($this->session->userdata('user_hotel'));
            /*if ($this->input->post('pages')) {
                $pages = $this->input->post('pages');
            } else {
                if ($this->session->flashdata('pages')) {
                    $pages = $this->session->flashdata('pages');
                } else {
                    $pages = 5;
                }
            }

            $this->session->set_flashdata('pages', $pages);

            $config['base_url'] = base_url() . 'dashboard/all_hotel_m';
            $config['total_rows'] = $this->dashboard_model->all_hotels_row();
            $config['per_page'] = $pages;
            $config['uri_segment'] = 3;
            $config['full_tag_open'] = "<ul class='pagination'>";
            $config['full_tag_close'] = "</ul>";
            $config['num_tag_open'] = '<li>';
            $config['num_tag_close'] = '</li>';
            $config['cur_tag_open'] = "<li class='disabled'><li class='active'><a href='#'>";
            $config['cur_tag_close'] = "<span class='sr-only'></span></a></li>";
            $config['next_tag_open'] = "<li>";
            $config['next_tagl_close'] = "</li>";
            $config['prev_tag_open'] = "<li>";
            $config['prev_tagl_close'] = "</li>";
            $config['first_tag_open'] = "<li>";
            $config['first_tagl_close'] = "</li>";
            $config['last_tag_open'] = "<li>";
            $config['last_tagl_close'] = "</li>";


            $this->pagination->initialize($config);

            $segment = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;*/

            //$data['hotels'] = $this->dashboard_model->all_hotels($config['per_page'], $segment);
            //$data['pagination'] = $this->pagination->create_links();
		    $data['hotels'] = $this->dashboard_model->all_hotels();
			//print_r($data);
			//exit();
            $data['page'] = 'backend/dashboard/all_hotel_m';
            $this->load->view('backend/common/index', $data);
        } else {
            redirect('dashboard');
        }
    }
    /* All Hotel End */

    /* Edit Hotel Start */
    function edit_hotel()
    {
        if($this->session->userdata('hotel_m') =='1') {
            $data['heading'] = 'Hotel';
            $data['sub_heading'] = 'Edit Hotel';
            $data['description'] = 'Edit Hotel Here';
            $data['active'] = 'edit_hotel';
            $data['country'] = $this->dashboard_model->get_country();
            $data['star'] = $this->dashboard_model->get_star_rating();
			$data['hotel_name'] = $this->dashboard_model->get_hotel($this->session->userdata('user_hotel'));
            if ($this->input->post()) {
                $table = TABLE_PRE . 'hotel_details';
                $this->form_validation->set_rules('hotel_name', 'Hotel Name', 'trim|required|xss_clean');
                $this->form_validation->set_rules('hotel_address', 'Address', 'trim|required|xss_clean');
                if ($this->input->post('hotel_email_hidden') != $this->input->post('hotel_email')) {
                    $this->form_validation->set_rules('hotel_email', 'Email Address', 'trim|required|valid_email|xss_clean|is_unique[' . $table . '.hotel_email]');
                } else {
                    $this->form_validation->set_rules('hotel_email', 'Email Address', 'trim|required|valid_email|xss_clean');
                }
                if ($this->input->post('hotel_phone_hidden') != $this->input->post('hotel_phone')) {
                    $this->form_validation->set_rules('hotel_phone', 'Phone Number', 'trim|required|numeric|max_length[10]|xss_clean|is_unique[' . $table . '.hotel_phone]');
                } else {
                    $this->form_validation->set_rules('hotel_phone', 'Phone Number', 'trim|required|numeric|max_length[10]|xss_clean');
                }
                if ($this->form_validation->run() == FALSE) {
                    $this->session->set_flashdata('err_msg', validation_errors());
                    redirect('dashboard/edit_hotel/' . base64url_encode($this->input->post('hotel_id')));
                } else {
                    date_default_timezone_set("Asia/Kolkata");
                    $hotel = array(
                        'hotel_id' => $this->input->post('hotel_id'),
                        'hotel_name' => $this->input->post('hotel_name'),
                        'hotel_address' => $this->input->post('hotel_address'),
                        'hotel_city' => $this->input->post('hotel_city'),
                        'hotel_district' => $this->input->post('hotel_district'),
                        'hotel_state' => $this->input->post('hotel_state'),
                        'hotel_country' => $this->input->post('hotel_country'),
                        'hotel_pin' => $this->input->post('hotel_pin'),
                        'hotel_email' => $this->input->post('hotel_email'),
                        'hotel_phone' => '+91' . $this->input->post('hotel_phone'),
                        'hotel_phone_alternative1' => $this->input->post('hotel_phone_alternative1'),
                        'hotel_phone_alternative2' => $this->input->post('hotel_phone_alternative2'),
                        'hotel_fax' => $this->input->post('hotel_fax'),
                        'hotel_url' => $this->input->post('hotel_url'),
                        'hotel_description' => $this->input->post('hotel_description'),
                        'hotel_star_rating' => $this->input->post('hotel_star_rating'),
                        'hotel_modify_date' => date("Y-m-d H:i:s")
                    );
                    $update = $this->dashboard_model->update_hotel($hotel);
                    $data['hotel'] = $this->dashboard_model->get_hotel($this->input->post('hotel_id'));
                    $this->session->set_flashdata('hotel', $data['hotel']);
                    if (isset($update) && $update) {
                        $this->session->set_flashdata('succ_msg', "Updated Successfully!");
                        redirect('dashboard/edit_hotel/' . base64url_encode($this->input->post('hotel_id')));
                    } else {
                        $this->session->set_flashdata('err_msg', "Database Error. Try Again Later!");
                        redirect('dashboard/edit_hotel/' . base64url_encode($this->input->post('hotel_id')));
                    }
                }
            }
            $hotel_id = (isset($hotel) && $hotel) ? $hotel['hotel_id'] : base64url_decode($this->uri->segment(3));
            $data['hotel'] = $this->dashboard_model->get_hotel($hotel_id);
            if (!$data['hotel'] || !$hotel_id || !$data['country']) {
                redirect('dashboard/all_hotels');
            }
            $data['page'] = 'backend/dashboard/edit_hotel';
            $this->load->view('backend/common/index', $data);
        } else {
            redirect('dashboard');
        }
    }
    /* Edit Hotel End */

    /* Delete Hotel Start */
    function hotel_delete()
    {
        if($this->session->userdata('hotel_m') =='1') {
            $this->form_validation->set_rules('delete[]', 'Select Hotel', 'trim|required|xss_clean');
            if ($this->form_validation->run() == FALSE) {
                $this->session->set_flashdata('err_msg', validation_errors());
                redirect('dashboard/all_hotels');
            } else {
                $hotel_id = $this->input->post('delete');
                $hotel = array(
                    'hotel_status' => 'D'
                );
                $update = $this->dashboard_model->delete_hotel($hotel_id, $hotel);
                if (isset($update) && $update) {
                    $this->session->set_flashdata('succ_msg', "Hotels Deleted!");
                    redirect('dashboard/all_hotels');
                } else {
                    $this->session->set_flashdata('err_msg', "Database Error. Try Again Later!");
                    redirect('dashboard/all_hotels');
                }
            }
        } else {
            redirect('dashboard');
        }

    }
    /* Delete Hotel End */

    /* Ajax Hotel Update Status Start */
    function hotel_update_status()
    {
        if($this->session->userdata('hotel_m') =='1') {
            $status = array(
                'hotel_id' => $this->input->post('id'),
                'hotel_status' => $this->input->post('value'),
            );
            $query = $this->dashboard_model->hotel_status_update($status);
            if (isset($query) && $query) {
                echo '<div class="alert alert-success alert-dismissible text-center" role="alert">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                    <strong>Status Updated Successfully!</strong>
                                </div>';
            } else {
                echo '<div class="alert alert-danger alert-dismissible text-center" role="alert">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                    <strong>Database Error. Try Again Later!</strong>
                                </div>';
            }

        } else {
            redirect('dashboard');
        }
    }
    /* Ajax Hotel Update Status End */

    /* Add Permission Start */
    function add_permission()
    {
        if ($this->session->userdata('user_type_slug') !== 'SUPA') {
            $data['heading'] = 'Permissions';
            $data['sub_heading'] = 'Add Permission';
            $data['description'] = 'Add Access Permission Here';
            $data['active'] = 'add_permission';
            $data['users'] = $this->dashboard_model->get_user_type();
			$data['hotel_name'] = $this->dashboard_model->get_hotel($this->session->userdata('user_hotel'));

            if ($this->input->post()) {
                $table = TABLE_PRE . 'permission_types';
                $this->form_validation->set_rules('permission_label', 'Permission Label', 'trim|required|xss_clean|is_unique[' . $table . '.permission_label]');
                $this->form_validation->set_rules('permission_description', 'Permission Description', 'trim|xss_clean');
                $this->form_validation->set_rules('permission_users[]', 'Permission Users', 'trim|required|xss_clean');
                $this->form_validation->set_rules('permission_val', 'Permission Values', 'trim|required|xss_clean');
                if ($this->form_validation->run() == FALSE) {
                    $this->session->set_flashdata('err_msg', validation_errors());
                    redirect('dashboard/add_permission');
                } else {
                    $permission_users = implode(",", $this->input->post('permission_users'));
                    $permission_val = explode(",", $this->input->post('permission_val'));
                    $i = 0;
                    foreach ($permission_val as $per) {
                        $permission[$i] = array(
                            'permission_label' => $this->input->post('permission_label'),
                            'permission_description' => $this->input->post('permission_description'),
                            'permission_users' => $permission_users,
                            'permission_value' => $per
                        );
                        $i++;
                    }

                    $query = $this->dashboard_model->add_permission($permission);

                    if (isset($query) && $query) {
                        $this->session->set_flashdata('succ_msg', "Permission Added Successfully!");
                        redirect('dashboard/add_permission');
                    } else {
                        $this->session->set_flashdata('err_msg', "Database Error. Try again later!");
                        redirect('dashboard/add_permission');
                    }
                }
            } else {
                $data['page'] = 'backend/dashboard/add_permission';
                $this->load->view('backend/common/index', $data);
            }
        } else {
            redirect('dashboard');
        }
    }
    /* Add Permission End */

    /* All Permission Start */
    function all_permissions()
    {
        if ($this->session->userdata('user_type_slug') !== 'SUPA') {
            $data['heading'] = 'Permissions';
            $data['sub_heading'] = 'All Permissions';
            $data['description'] = 'Added Permissions List';
            $data['active'] = 'all_permissions';
			$data['hotel_name'] = $this->dashboard_model->get_hotel($this->session->userdata('user_hotel'));

            if ($this->input->post('pages')) {
                $pages = $this->input->post('pages');
            } else {
                if ($this->session->flashdata('pages')) {
                    $pages = $this->session->flashdata('pages');
                } else {
                    $pages = 5;
                }
            }

            $this->session->set_flashdata('pages', $pages);

            $config['base_url'] = base_url() . 'dashboard/all_permissions';
            $config['total_rows'] = $this->dashboard_model->all_permissions_row();
            $config['per_page'] = $pages;
            $config['uri_segment'] = 3;
            $config['full_tag_open'] = "<ul class='pagination'>";
            $config['full_tag_close'] = "</ul>";
            $config['num_tag_open'] = '<li>';
            $config['num_tag_close'] = '</li>';
            $config['cur_tag_open'] = "<li class='disabled'><li class='active'><a href='#'>";
            $config['cur_tag_close'] = "<span class='sr-only'></span></a></li>";
            $config['next_tag_open'] = "<li>";
            $config['next_tagl_close'] = "</li>";
            $config['prev_tag_open'] = "<li>";
            $config['prev_tagl_close'] = "</li>";
            $config['first_tag_open'] = "<li>";
            $config['first_tagl_close'] = "</li>";
            $config['last_tag_open'] = "<li>";
            $config['last_tagl_close'] = "</li>";


            $this->pagination->initialize($config);

            $segment = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;

            $data['permissions'] = $this->dashboard_model->all_permissions($config['per_page'], $segment);
            $data['pagination'] = $this->pagination->create_links();

            $data['page'] = 'backend/dashboard/all_permissions';
            $this->load->view('backend/common/index', $data);
        } else {
            redirect('dashboard');
        }
    }
    /* All Permission End */

    /* Edit Permission Start */
    function edit_permission()
    {
        if ($this->session->userdata('user_type_slug') !== 'SUPA') {
            $data['heading'] = 'Permissions';
            $data['sub_heading'] = 'Edit Permission';
            $data['description'] = 'Edit Permission Here';
            $data['active'] = 'edit_permission';
            $data['users'] = $this->dashboard_model->get_user_type();
			$data['hotel_name'] = $this->dashboard_model->get_hotel($this->session->userdata('user_hotel'));

            if ($this->input->post()) {
                $table = TABLE_PRE . 'permission_types';

                $this->form_validation->set_rules('permission_description', 'Permission Description', 'trim|xss_clean');
                $this->form_validation->set_rules('permission_users[]', 'Permission Users', 'trim|required|xss_clean');
                $this->form_validation->set_rules('permission_val', 'Permission Values', 'trim|required|xss_clean');
                if ($this->input->post('permission_label_hidden') != $this->input->post('permission_label')) {
                    $this->form_validation->set_rules('permission_label', 'Permission Label', 'trim|required|xss_clean|is_unique[' . $table . '.permission_label]');
                } else {
                    $this->form_validation->set_rules('permission_label', 'Permission Label', 'trim|required|xss_clean');
                }
                if ($this->form_validation->run() == FALSE) {
                    $this->session->set_flashdata('err_msg', validation_errors());
                    redirect('dashboard/edit_permission/' . base64url_encode($this->input->post('permission_id')));
                } else {
                    $permission_id = explode(",", $this->input->post('permission_id'));
                    $permission_users = implode(",", $this->input->post('permission_users'));
                    $permission_val = explode(",", $this->input->post('permission_val'));
                    $i = 0;
                    foreach ($permission_id as $per) {
                        $permission[$i] = array(
                            'permission_id' => $per,
                            'permission_label' => $this->input->post('permission_label'),
                            'permission_description' => $this->input->post('permission_description'),
                            'permission_users' => $permission_users,
                            'permission_value' => $permission_val[$i]
                        );
                        $i++;
                    }
                    $update = $this->dashboard_model->update_permission($permission);
                    $data['permission'] = $this->dashboard_model->get_permission($per);
                    $this->session->set_flashdata('permission', $data['permission']);
                    if (isset($update) && $update) {
                        $this->session->set_flashdata('succ_msg', "Updated Successfully!");
                        redirect('dashboard/edit_permission/' . base64url_encode($permission_id[0]));
                    } else {
                        $this->session->set_flashdata('err_msg', "Database Error. Try Again Later!");
                        redirect('dashboard/edit_permission/' . base64url_encode($permission_id[0]));
                    }
                }
            }
            $permission_id = (isset($permission) && $permission) ? $permission['permission_id'] : base64url_decode($this->uri->segment(3));
            $data['permission'] = $this->dashboard_model->get_permission($permission_id);
            if (!$data['permission'] || !$permission_id) {
                redirect('dashboard/all_permissions');
            }
            $data['page'] = 'backend/dashboard/edit_permission';
            $this->load->view('backend/common/index', $data);
        } else {
            redirect('dashboard');
        }
    }
    /* Edit Permission End */

    /*Start Lock Screen*/
    function lock_screen()
    {

    }

    /* Add Room Start */
    function add_room()
    {
        if($this->session->userdata('room') =='1') {
            $data['heading'] = 'Room';
            $data['sub_heading'] = 'Add Room';
            $data['description'] = 'Add Room Here';
            $data['active'] = 'add_room';
			$data['hotel_name'] = $this->dashboard_model->get_hotel($this->session->userdata('user_hotel'));
			
			if ($this->input->post()) {
				
					$room_feature = $this->input->post('room_feature');
					$room_feature_string = "";
					$room_feature_string =  $room_feature_string.implode(',' , $room_feature);
					
					$room_image = "";
					$room_thumb="";
					$this->upload->initialize($this->set_upload_options());
					if ($this->upload->do_upload('image')) {
                        $room_image = $this->upload->data('file_name');
                        $filename = $room_image;
                        $source_path = './upload/' . $filename;
                        $target_path = './upload/thumb/';
                        $config_manip = array(
                            'image_library' => 'gd2',
                            'source_image' => $source_path,
                            'new_image' => $target_path,
                            'maintain_ratio' => TRUE,
                            'create_thumb' => TRUE,
                            'thumb_marker' => '_thumb',
                            'width' => 100,
                            'height' => 100
                        );
                        $this->load->library('image_lib', $config_manip);
                        if (!$this->image_lib->resize()) {
                            $this->session->set_flashdata('err_msg', $this->image_lib->display_errors());
                            redirect('dashboard/add_room');
                        }
                        // clear //
                        $thumb_name = explode(".", $filename);
                        $room_thumb = $thumb_name[0] . $config_manip['thumb_marker'] . "." . $thumb_name[1];
                        $this->image_lib->clear();
                    } 
					date_default_timezone_set("Asia/Kolkata");
                    $room = array(
                        'hotel_id' => $this->session->userdata('user_hotel'),
                        'floor_no' => $this->input->post('floor_no'),
                        'room_no'  => $this->input->post('room_no'),
                        'room_bed' => $this->input->post('room_bed'),
                        'room_features' => $room_feature_string,
                        'room_rent' => $this->input->post('room_rent'),
                        'room_image' => $room_image,
                        'room_image_thumb' =>  $room_thumb,
                        'room_add_date' => date("Y-m-d H:i:s"),
                        'room_modification_date' => date("Y-m-d H:i:s")
                    );
                    //print_r($room);
					//exit();
					
					$query = $this->dashboard_model->add_room($room);

                    if (isset($query) && $query) {
                        $this->session->set_flashdata('succ_msg', "Room Added Successfully!");
                        redirect('dashboard/add_room');
                    } else {
                        $this->session->set_flashdata('err_msg', "Database Error. Try again later!");
                        redirect('dashboard/add_room');
                    }
			
			
			
			
			
			} else {
                $data['page'] = 'backend/dashboard/add_room';
                $this->load->view('backend/common/index', $data);
            }
           
        } else {
            redirect('dashboard');
        }
    }
    /* Add Room End */

    /* All Rooms Start */
    function all_rooms()
    {
        if($this->session->userdata('room') =='1') {
            $data['heading'] = 'Room';
            $data['sub_heading'] = 'All Rooms';
            $data['description'] = 'Added Rooms List';
            $data['active'] = 'all_rooms';
			$data['hotel_name'] = $this->dashboard_model->get_hotel($this->session->userdata('user_hotel'));

           /* if ($this->input->post('pages')) {
                $pages = $this->input->post('pages');
            } else {
                if ($this->session->flashdata('pages')) {
                    $pages = $this->session->flashdata('pages');
                } else {
                    $pages = 5;
                }
            }

            $this->session->set_flashdata('pages', $pages);

            $config['base_url'] = base_url() . 'dashboard/all_rooms';
            $config['total_rows'] = $this->dashboard_model->all_rooms_row();
            $config['per_page'] = $pages;
            $config['uri_segment'] = 3;
            $config['full_tag_open'] = "<ul class='pagination'>";
            $config['full_tag_close'] = "</ul>";
            $config['num_tag_open'] = '<li>';
            $config['num_tag_close'] = '</li>';
            $config['cur_tag_open'] = "<li class='disabled'><li class='active'><a href='#'>";
            $config['cur_tag_close'] = "<span class='sr-only'></span></a></li>";
            $config['next_tag_open'] = "<li>";
            $config['next_tagl_close'] = "</li>";
            $config['prev_tag_open'] = "<li>";
            $config['prev_tagl_close'] = "</li>";
            $config['first_tag_open'] = "<li>";
            $config['first_tagl_close'] = "</li>";
            $config['last_tag_open'] = "<li>";
            $config['last_tagl_close'] = "</li>";


            $this->pagination->initialize($config);

            $segment = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;*/

            //$data['rooms'] = $this->dashboard_model->all_rooms($config['per_page'], $segment);
			$data['rooms'] = $this->dashboard_model->all_rooms();
            //$data['pagination'] = $this->pagination->create_links();

            $data['page'] = 'backend/dashboard/all_rooms';
            $this->load->view('backend/common/index', $data);
        } else {
            redirect('dashboard');
        }
    }
    /* All Rooms End */

    /* Upload Start */
    function set_upload_options()
    {
        $config = array(
            'upload_path' => './upload/',
            'allowed_types' => 'gif|jpg|png',
            'overwrite' => FALSE
        );
        return $config;
    }

    /* Upload End */

    function test($abc)
    {
        echo $abc;
    }




    public function add_booking(){

        if($this->session->userdata('booking') =='1'){
            $data['heading']='Booking';
            $data['sub_heading']='Add Booking';
            $data['description']='Add Booking Here';
            $data['active']='add_booking';
			$data['hotel_name'] = $this->dashboard_model->get_hotel($this->session->userdata('user_hotel'));

            if($this->input->post()) {


                $rooms = $this->dashboard_model->get_room_id($this->session->userdata('user_hotel'), $this->input->post('room_no'));
                if (!$rooms) {

                    $this->session->set_flashdata('err_msg', "Room Number for this hotel not found. Please add new room. ");
                    $data['page'] = 'backend/dashboard/add_booking';
                    $this->load->view('backend/common/index', $data);

                } else {

                    foreach ($rooms as $room) {

                        $room_id = $room->room_id;

                    }

                    date_default_timezone_set("Asia/Kolkata");
                    $bookings = array(

                        'room_id' => $room_id,
                        'cust_name' => $this->input->post('cust_name'),
                        'cust_address' => $this->input->post('cust_address'),
                        'cust_contact_no' => $this->input->post('cust_contact_no'),
                        'cust_from_date' => $this->input->post('cust_from_date'),
                        'cust_end_date' => $this->input->post('cust_end_date'),
                        'cust_booking_status' => $this->input->post('cust_booking_status'),
                        'cust_payment_initial' =>$this->input->post('cust_payment_initial'),

                    );
                    $query = $this->dashboard_model->add_booking($bookings);

                    if (isset($query) && $query) {
                        $this->session->set_flashdata('succ_msg', "Booking Added Successfully!");
                        redirect('dashboard/add_booking');
                    } else {
                        $this->session->set_flashdata('err_msg', "Database Error. Try again later!");
                        redirect('dashboard/add_booking');
                    }

                }}
            else{
                $data['page'] = 'backend/dashboard/add_booking';
                $this->load->view('backend/common/index', $data);
            }
        }else{
            redirect('dashboard');
        }
    }

	public function add_booking_calendar(){

        if($this->session->userdata('booking') =='1'){
            $data['heading']='Booking';
            $data['sub_heading']='Add Booking Calendar';
            $data['description']='Add Booking Here';
            $data['active']='add_booking_calendar';
			$data['hotel_name'] = $this->dashboard_model->get_hotel($this->session->userdata('user_hotel'));
            
           
            $data['page'] = 'backend/dashboard/add_booking_calendar';
            $this->load->view('backend/common/index', $data);
          
        }else{
            redirect('dashboard');
        }
    }
    function all_bookings()
    {
        if($this->session->userdata('booking') =='1') {
            $data['heading'] = 'Booking';
            $data['sub_heading'] = 'All Bookings';
            $data['description'] = 'Bookings List';
            $data['active'] = 'all_bookings';
			$data['hotel_name'] = $this->dashboard_model->get_hotel($this->session->userdata('user_hotel'));
            /*if ($this->input->post('pages')) {
                $pages = $this->input->post('pages');
            } else {
                if ($this->session->flashdata('pages')) {
                    $pages = $this->session->flashdata('pages');
                } else {
                    $pages = 5;
                }
            }

            $this->session->set_flashdata('pages', $pages);

            $config['base_url'] = base_url() . 'dashboard/all_rooms';
            $config['total_rows'] = $this->dashboard_model->all_rooms_row();
            $config['per_page'] = $pages;
            $config['uri_segment'] = 3;
            $config['full_tag_open'] = "<ul class='pagination'>";
            $config['full_tag_close'] = "</ul>";
            $config['num_tag_open'] = '<li>';
            $config['num_tag_close'] = '</li>';
            $config['cur_tag_open'] = "<li class='disabled'><li class='active'><a href='#'>";
            $config['cur_tag_close'] = "<span class='sr-only'></span></a></li>";
            $config['next_tag_open'] = "<li>";
            $config['next_tagl_close'] = "</li>";
            $config['prev_tag_open'] = "<li>";
            $config['prev_tagl_close'] = "</li>";
            $config['first_tag_open'] = "<li>";
            $config['first_tagl_close'] = "</li>";
            $config['last_tag_open'] = "<li>";
            $config['last_tagl_close'] = "</li>";


            $this->pagination->initialize($config);

            $segment = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;*/

            //$data['bookings'] = $this->dashboard_model->all_bookings($config['per_page'], $segment);
			$data['bookings'] = $this->dashboard_model->all_bookings();
            $data['transactions'] = $this->dashboard_model->all_transactions();
            //$data['pagination'] = $this->pagination->create_links();

            $data['page'] = 'backend/dashboard/all_bookings';
            $this->load->view('backend/common/index', $data);

        } else {
            redirect('dashboard');
        }
    }
    /* All Bookings End */

    // Transaction starts (Add Transaction)

    public function add_transaction(){
		
        if($this->session->userdata('transaction') =='1'){
            $data['heading']='Transaction';
            $data['sub_heading']='Add Transaction';
            $data['description']='Add Transaction Here';
            $data['active']='add_transaction';
			$data['hotel_name'] = $this->dashboard_model->get_hotel($this->session->userdata('user_hotel'));
			//19.11.2015
			/*if($this->input->post('term'))
			{
				echo $this->input->post('term');
			}*/

            if($this->input->post()) {

                date_default_timezone_set("Asia/Kolkata");
                $transactions = array(


                    't_booking_id' => $this->input->post('t_booking_id'),
                    't_amount' => $this->input->post('t_amount'),
                    //'t_date' => date("Y-m-d H:i:s"),
                    't_payment_mode' => $this->input->post('t_payment_mode'),
                    't_status' =>$this->input->post('t_payment_status'),

                );
                $query = $this->dashboard_model->add_transaction($transactions);

                if (isset($query) && $query) {
                    $this->session->set_flashdata('succ_msg', "Transaction Added Successfully!");
                    redirect('dashboard/add_transaction');
                } else {
                    $this->session->set_flashdata('err_msg', "Database Error. Try again later!");
                    redirect('dashboard/add_transaction');
                }

            }
            else{
				
				//$this->load->model('Dashboard_model');
				
				//echo $book_id;
				$data['booking'] =  $this->dashboard_model->all_booking_id();
                $data['page'] = 'backend/dashboard/add_transaction';
                $this->load->view('backend/common/index', $data);
            }
        }else{
            redirect('dashboard');
        }
    }

    function all_transactions()
    {
        if($this->session->userdata('transaction') =='1') {
            $data['heading'] = 'Transaction';
            $data['sub_heading'] = 'All Transactions';
            $data['description'] = 'Transaction List';
            $data['active'] = 'all_transactions';
			$data['hotel_name'] = $this->dashboard_model->get_hotel($this->session->userdata('user_hotel'));
            /*if ($this->input->post('pages')) {
                $pages = $this->input->post('pages');
            } else {
                if ($this->session->flashdata('pages')) {
                    $pages = $this->session->flashdata('pages');
                } else {
                    $pages = 5;
                }
            }

            $this->session->set_flashdata('pages', $pages);

            $config['base_url'] = base_url() . 'dashboard/all_transactions';
            $config['total_rows'] = $this->dashboard_model->all_transactions_row();
            $config['per_page'] = $pages;
            $config['uri_segment'] = 3;
            $config['full_tag_open'] = "<ul class='pagination'>";
            $config['full_tag_close'] = "</ul>";
            $config['num_tag_open'] = '<li>';
            $config['num_tag_close'] = '</li>';
            $config['cur_tag_open'] = "<li class='disabled'><li class='active'><a href='#'>";
            $config['cur_tag_close'] = "<span class='sr-only'></span></a></li>";
            $config['next_tag_open'] = "<li>";
            $config['next_tagl_close'] = "</li>";
            $config['prev_tag_open'] = "<li>";
            $config['prev_tagl_close'] = "</li>";
            $config['first_tag_open'] = "<li>";
            $config['first_tagl_close'] = "</li>";
            $config['last_tag_open'] = "<li>";
            $config['last_tagl_close'] = "</li>";


            $this->pagination->initialize($config);

            $segment = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;*/

            //$data['transactions'] = $this->dashboard_model->all_transactions_limit($config['per_page'], $segment);
            //$data['pagination'] = $this->pagination->create_links();
			$data['transactions'] = $this->dashboard_model->all_transactions_limit();
            $data['page'] = 'backend/dashboard/all_transactions';
            $this->load->view('backend/common/index', $data);

        } else {
            redirect('dashboard');
        }
    }


    function edit_room(){

        if($this->session->userdata('room') =='1') {
            $data['heading'] = 'Room';
            $data['sub_heading'] = 'Edit Room';
            $data['description'] = 'Edit Room Here';
            $data['active'] = 'edit_room';
			$data['hotel_name'] = $this->dashboard_model->get_hotel($this->session->userdata('user_hotel'));

            if ($this->input->post()) {
                $table = TABLE_PRE . 'room';



                date_default_timezone_set("Asia/Kolkata");
                $room = array(
                    'room_id' =>$this->input->post('room_id'),
                    'hotel_id' =>$this->session->userdata('user_hotel'),
                    'floor_no' => $this->input->post('floor_no'),
                    'room_no' => $this->input->post('room_no'),
                    'room_bed' => $this->input->post('room_bed'),
                    'ac_availability' => $this->input->post('ac_availability'),
                    'room_rent' => $this->input->post('room_rent'),
                    'room_add_date' => date("Y-m-d H:i:s"),
                    'room_modification_date' => date("Y-m-d H:i:s")
                );
                $update = $this->dashboard_model->update_room($room);
                $data['room'] = $this->dashboard_model->get_room($this->input->post('room_id'));
                $this->session->set_flashdata('room', $data['room_id']);
                if (isset($update) && $update) {
                    $this->session->set_flashdata('succ_msg', "Updated Successfully!");
                    redirect('dashboard/edit_room/' . base64url_encode($this->input->post('room_id')));
                } else {
                    $this->session->set_flashdata('err_msg', "Database Error. Try Again Later!");
                    redirect('dashboard/edit_room/' . base64url_encode($this->input->post('room_id')));
                }

            }
            $room_id = (isset($room) && $room) ? $room['room_id'] : base64_decode($this->uri->segment(3));
            $data['room'] = $this->dashboard_model->get_room($room_id);
            if (!$data['room'] || !$room_id ) {
                //redirect('dashboard/edit_room');
            }
            $data['page'] = 'backend/dashboard/edit_room';
            $this->load->view('backend/common/index', $data);
        } else {
            redirect('dashboard');

        }
    }



    /*Add Compliance */

    public function add_compliance(){

        if($this->session->userdata('compliance') =='1'){
            $data['heading']='Compliance';
            $data['sub_heading']='Add Compliance';
            $data['description']='Add Compliance Here';
            $data['active']='add_compliance';
			$data['hotel_name'] = $this->dashboard_model->get_hotel($this->session->userdata('user_hotel'));
            if($this->input->post()) {
				
					/*20.11.2015 _ Images Upload */
					$this->upload->initialize($this->set_upload_options());
					if ($this->upload->do_upload('image_certificate') ) {
						
							$certificate_image = $this->upload->data('file_name');
							$filename = $certificate_image;
                        	$source_path = './upload/' . $filename;
                        	$target_path = './upload/certificate/';
                        	
							$config_manip = array(
                            'image_library' => 'gd2',
                            'source_image' => $source_path,
                            'new_image' => $target_path,
                            'maintain_ratio' => TRUE,
                            'create_thumb' => TRUE,
                            'thumb_marker' => '_thumb',
                            'width' => 100,
                            'height' => 100
                        	);
                        	$this->load->library('image_lib', $config_manip);
							
							if (!$this->image_lib->resize()) {
                            		$this->session->set_flashdata('err_msg', $this->image_lib->display_errors());
                            		redirect('dashboard/add_guest');
                        	}
                        		// clear //
                        			$thumb_name = explode(".", $filename);
                        			$certificate_thumb = $thumb_name[0] . $config_manip['thumb_marker'] . "." . $thumb_name[1];
                        			$this->image_lib->clear();
					}
					else{
						
                        $this->session->set_flashdata('err_msg', $this->upload->display_errors());
                        redirect('dashboard/add_compliance');
                    }
					
					/*20.11.2015 _ Images Upload */

                	
					
					
					date_default_timezone_set("Asia/Kolkata");
                	$compliance = array(

                    'hotel_id' => $this->session->userdata('user_hotel'),
                    'c_valid_for' => $this->input->post('c_valid_for'),
                    'c_name' => $this->input->post('c_name'),
                    'c_owner' => $this->input->post('c_owner'),
                    'c_description' => $this->input->post('c_description'),
                    'c_type' => $this->input->post('c_type'),
                    'c_importance' => $this->input->post('c_importance'),
                    'c_valid_from' => $this->input->post('c_valid_from'),
                    'c_valid_upto' => $this->input->post('c_valid_upto'),
                    'c_renewal' => $this->input->post('c_renewal'),
                    'c_file' => $certificate_image,
					'c_file_thumb' => $certificate_thumb, 
                    'c_primary_notif_period' => $this->input->post('c_primary'),
                    'c_secondary_notif_period' => $this->input->post('c_secondary'),

					'c_authority' => $this->input->post('c_authority'),



                	);
                    /*echo "<pre>";
                    print_r($compliance);
                    exit();*/
                	$query = $this->dashboard_model->add_compliance($compliance);

                	if (isset($query) && $query) {
                    	$this->session->set_flashdata('succ_msg', "Compliance Added Successfully!");
                    	redirect('dashboard/add_compliance');
                	} else {
                    	$this->session->set_flashdata('err_msg', "Database Error. Try again later!");
                    	redirect('dashboard/add_compliance');
                	}

            	}
            	else{
                	$data['page'] = 'backend/dashboard/add_compliance';
                	$this->load->view('backend/common/index', $data);
            	}
        }else{
            redirect('dashboard');
        }
    }


    function all_compliance()
    {
        if($this->session->userdata('compliance') =='1') {
            $data['heading'] = 'Compliance';
            $data['sub_heading'] = 'All compliance';
            $data['description'] = 'Compliance List';
            $data['active'] = 'all_compliance';
			$data['hotel_name'] = $this->dashboard_model->get_hotel($this->session->userdata('user_hotel'));
            /*if ($this->input->post('pages')) {
                $pages = $this->input->post('pages');
            } else {
                if ($this->session->flashdata('pages')) {
                    $pages = $this->session->flashdata('pages');
                } else {
                    $pages = 5;
                }
            }

            $this->session->set_flashdata('pages', $pages);

            $config['base_url'] = base_url() . 'dashboard/all_transactions';
            $config['total_rows'] = $this->dashboard_model->all_compliance_row();
            $config['per_page'] = $pages;
            $config['uri_segment'] = 3;
            $config['full_tag_open'] = "<ul class='pagination'>";
            $config['full_tag_close'] = "</ul>";
            $config['num_tag_open'] = '<li>';
            $config['num_tag_close'] = '</li>';
            $config['cur_tag_open'] = "<li class='disabled'><li class='active'><a href='#'>";
            $config['cur_tag_close'] = "<span class='sr-only'></span></a></li>";
            $config['next_tag_open'] = "<li>";
            $config['next_tagl_close'] = "</li>";
            $config['prev_tag_open'] = "<li>";
            $config['prev_tagl_close'] = "</li>";
            $config['first_tag_open'] = "<li>";
            $config['first_tagl_close'] = "</li>";
            $config['last_tag_open'] = "<li>";
            $config['last_tagl_close'] = "</li>";


            $this->pagination->initialize($config);

            $segment = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;*/

            //$data['compliance'] = $this->dashboard_model->all_compliance_limit($config['per_page'], $segment);
            //$data['pagination'] = $this->pagination->create_links();
			
			$data['compliance'] = $this->dashboard_model->all_compliance_limit();
            $data['page'] = 'backend/dashboard/all_compliance';
            $this->load->view('backend/common/index', $data);

        } else {
            redirect('dashboard');
        }
    }




    function add_hrm(){

        $data['page'] = 'backend/dashboard/add_hrm';
        $this->load->view('backend/common/index', $data);
    }
    function all_hrm(){
        $data['page'] = 'backend/dashboard/all_hrm';
        $this->load->view('backend/common/index', $data);
    }
    /*function add_hotel_m(){
        $data['page'] = 'backend/dashboard/add_hotel_m';
        $this->load->view('backend/common/index', $data);
    }*/

   /* function all_hotel_m(){
        $data['page'] = 'backend/dashboard/all_hotel_m';
        $this->load->view('backend/common/index', $data);
    } */
    public function add_guest(){
		
	/*18.11.2015 */
	if($this->session->userdata('guest') == '1')
	{
		$data['heading']='Guests';
        $data['sub_heading']='Add Guest';
        $data['description']='Add Guest Here';
        $data['active']='add_guest';
		$data['hotel_name'] = $this->dashboard_model->get_hotel($this->session->userdata('user_hotel'));
			if($this->input->post())
			{	
					/* Images Upload */
						$this->upload->initialize($this->set_upload_options());
						if ($this->upload->do_upload('image_photo') ) {
							/*  Image Upload 18.11.2015 */
							$room_image = $this->upload->data('file_name');
							$filename = $room_image;
                        	$source_path = './upload/' . $filename;
                        	$target_path = './upload/guest/';
                        	
							$config_manip = array(
                            'image_library' => 'gd2',
                            'source_image' => $source_path,
                            'new_image' => $target_path,
                            'maintain_ratio' => TRUE,
                            'create_thumb' => TRUE,
                            'thumb_marker' => '_thumb',
                            'width' => 100,
                            'height' => 100
                        	);
                        	$this->load->library('image_lib', $config_manip);
							
							if (!$this->image_lib->resize()) {
                            		$this->session->set_flashdata('err_msg', $this->image_lib->display_errors());
                            		redirect('dashboard/add_guest');
                        	}
                        		// clear //
                        			$thumb_name = explode(".", $filename);
                        			$room_thumb = $thumb_name[0] . $config_manip['thumb_marker'] . "." . $thumb_name[1];
                        			$this->image_lib->clear();
						   /* Images Upload  18.11.2015 */ 
						  
						}
						else 
						{
                        	$this->session->set_flashdata('err_msg', $this->upload->display_errors());
                        	redirect('dashboard/add_guest');
                    	}
					
					
						/* Id Proof Upload*/ 
							$this->upload->initialize($this->set_upload_options());
							if ($this->upload->do_upload('image_idpf')) {
							/*  Image Upload 18.11.2015 */
							$room_image1 = $this->upload->data('file_name');
							$filename1 = $room_image1;
                        	$source_path1 = './upload/' . $filename1;
                        	$target_path1 = './upload/guest/';
                        	
							$config_manip1 = array(
                            'image_library' => 'gd2',
                            'source_image' => $source_path1,
                            'new_image' => $target_path1,
                            'maintain_ratio' => TRUE,
                            'create_thumb' => TRUE,
                            'thumb_marker' => '_thumb',
                            'width' => 100,
                            'height' => 100
                        	);
                        	$this->load->library('image_lib', $config_manip1);
							
							if (!$this->image_lib->resize()) {
                            		$this->session->set_flashdata('err_msg', $this->image_lib->display_errors());
                            		redirect('dashboard/add_guest');
                        	}
                        		// clear //
                        			$thumb_name1 = explode(".", $filename1);
                        			$room_thumb1 = $thumb_name1[0] . $config_manip1['thumb_marker'] . "." . $thumb_name1[1];
                        			$this->image_lib->clear();
						   /* Images Upload  18.11.2015 */ 
						  
						}
						else 
						{
                        	$this->session->set_flashdata('err_msg', $this->upload->display_errors());
                        	redirect('dashboard/add_guest');
                    	}
						/* Id Proof Upload*/
					
					
					/* Images Upload*/ 
					date_default_timezone_set("Asia/Kolkata");
					$guest = array(

					'hotel_id' => $this->session->userdata('user_hotel'),
					'g_name' => $this->input->post('g_name'),
					'g_place' => '',
					'g_address' => $this->input->post('g_address'),
					'g_contact_no' => $this->input->post('g_contact_no'),
					'g_email' => $this->input->post('g_email'),
					'g_gender' => $this->input->post('g_gender'),
					'g_dob' =>   date("Y-m-d", strtotime($this->input->post('g_dob'))),
					'g_occupation' => $this->input->post('g_occupation'),
					'g_married' => $this->input->post('g_married'),
					'g_id_type' => $this->input->post('g_id_type'),
					'g_photo' => $room_image,
					'g_id_proof' => $room_image1,
					'g_photo_thumb' => $room_thumb,
					'g_id_proof_thumb' => $room_thumb1,
					'g_pincode' => $this->input->post('g_place'),
					'g_city' => $this->input->post('g_city'),
					'g_state' => $this->input->post('g_state'),
					'g_country' => $this->input->post('g_country')
					);
				    
                    /*print_r($guest);
                    exit();*/
            		$query = $this->dashboard_model->add_guest($guest);
					if (isset($query) && $query) 
					{
                		$this->session->set_flashdata('succ_msg', "Guest Added Successfully!");
                		redirect('dashboard/add_guest');
            		} 
					else 
					{
                		$this->session->set_flashdata('err_msg', "Database Error. Try again later!");
                		redirect('dashboard/add_guest');
            		}
					
			}
			else
			{
            	$data['page'] = 'backend/dashboard/add_guest';
            	$this->load->view('backend/common/index', $data);
        	}
		
	}
	else
	{
		redirect('dashboard');
	}
	
	
	
	/* 18.11.2015 */

    /*if($this->session->userdata('guest') =='1'){
        $data['heading']='Guests';
        $data['sub_heading']='Add Guest';
        $data['description']='Add Guest Here';
        $data['active']='add_guest';

        		if($this->input->post()) {
						
					date_default_timezone_set("Asia/Kolkata");
					$guest = array(

					'hotel_id' => $this->session->userdata('user_hotel'),
					'g_name' => $this->input->post('g_name'),
					'g_place' => $this->input->post('g_place'),
					'g_address' => $this->input->post('g_address'),
					'g_contact_no' => $this->input->post('g_contact_no'),
					'g_email' => $this->input->post('g_email'),
					'g_gender' => $this->input->post('g_gender'),
					'g_dob' => $this->input->post('g_dob'),
					'g_occupation' => $this->input->post('g_occupation'),
					'g_married' => $this->input->post('g_married'),
					'g_id_type' => $this->input->post('g_id_type'),
					'g_photo' => '',
					'g_id_proof' => '',
					);
				
            		$query = $this->dashboard_model->add_guest($guest);

            		if (isset($query) && $query) {
                		$this->session->set_flashdata('succ_msg', "Guest Added Successfully!");
                		redirect('dashboard/add_guest');
            		} else {
                		$this->session->set_flashdata('err_msg', "Database Error. Try again later!");
                		redirect('dashboard/add_guest');
            		}

	        }
        	else{
            	$data['page'] = 'backend/dashboard/add_guest';
            	$this->load->view('backend/common/index', $data);
        	}
    }else{
        redirect('dashboard');
    }*/
}


    function all_guest()
    {
        if($this->session->userdata('guest') =='1') {
            $data['heading'] = 'Guests';
            $data['sub_heading'] = 'All Guest';
            $data['description'] = 'Guest List';
            $data['active'] = 'all_guest';
			$data['hotel_name'] = $this->dashboard_model->get_hotel($this->session->userdata('user_hotel'));
            /*if ($this->input->post('pages')) {
                $pages = $this->input->post('pages');
            } else {
                if ($this->session->flashdata('pages')) {
                    $pages = $this->session->flashdata('pages');
                } else {
                    $pages = 5;
                }
            }

            $this->session->set_flashdata('pages', $pages);

            $config['base_url'] = base_url() . 'dashboard/all_guest';
            $config['total_rows'] = $this->dashboard_model->all_guest_row();
            $config['per_page'] = $pages;
            $config['uri_segment'] = 3;
            $config['full_tag_open'] = "<ul class='pagination'>";
            $config['full_tag_close'] = "</ul>";
            $config['num_tag_open'] = '<li>';
            $config['num_tag_close'] = '</li>';
            $config['cur_tag_open'] = "<li class='disabled'><li class='active'><a href='#'>";
            $config['cur_tag_close'] = "<span class='sr-only'></span></a></li>";
            $config['next_tag_open'] = "<li>";
            $config['next_tagl_close'] = "</li>";
            $config['prev_tag_open'] = "<li>";
            $config['prev_tagl_close'] = "</li>";
            $config['first_tag_open'] = "<li>";
            $config['first_tagl_close'] = "</li>";
            $config['last_tag_open'] = "<li>";
            $config['last_tagl_close'] = "</li>";


            $this->pagination->initialize($config);

            $segment = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;

            $data['guest'] = $this->dashboard_model->all_guest_limit($config['per_page'], $segment);
            $data['pagination'] = $this->pagination->create_links();*/
			$data['guest'] = $this->dashboard_model->all_guest_limit_view();
            $data['page'] = 'backend/dashboard/all_guest';
            $this->load->view('backend/common/index', $data);

        } else {
            redirect('dashboard');
        }
    }

    public function add_broker(){

        if($this->session->userdata('broker') =='1'){
            $data['heading']='Broker';
            $data['sub_heading']='Add Broker';
            $data['description']='Add Broker Here';
            $data['active']='add_broker';
			$data['hotel_name'] = $this->dashboard_model->get_hotel($this->session->userdata('user_hotel'));
            if($this->input->post()) {
				
				
				/* Images Upload */
						$this->upload->initialize($this->set_upload_options());
						if ($this->upload->do_upload('image_photo') ) {
							/*  Image Upload 18.11.2015 */
							$room_image = $this->upload->data('file_name');
							$filename = $room_image;
                        	$source_path = './upload/' . $filename;
                        	$target_path = './upload/broker/';
                        	
							$config_manip = array(
                            'image_library' => 'gd2',
                            'source_image' => $source_path,
                            'new_image' => $target_path,
                            'maintain_ratio' => TRUE,
                            'create_thumb' => TRUE,
                            'thumb_marker' => '_thumb',
                            'width' => 100,
                            'height' => 100
                        	);
                        	$this->load->library('image_lib', $config_manip);
							
							if (!$this->image_lib->resize()) {
                            		$this->session->set_flashdata('err_msg', $this->image_lib->display_errors());
                            		redirect('dashboard/add_guest');
                        	}
                        		// clear //
                        			$thumb_name = explode(".", $filename);
                        			$room_thumb = $thumb_name[0] . $config_manip['thumb_marker'] . "." . $thumb_name[1];
                        			$this->image_lib->clear();
						   /* Images Upload  18.11.2015 */ 
						  
						}
						else 
						{
                        	$this->session->set_flashdata('err_msg', $this->upload->display_errors());
                        	redirect('dashboard/add_guest');
                    	}

                date_default_timezone_set("Asia/Kolkata");
				/*$files = $_FILES['image_photo'];
				print_r($files);
				$this->load->library('upload');
				$new_name = str_replace(".","",microtime());		
				$config1['upload_path'] =FCPATH . 'upload/';
				$config1['allowed_types'] = 'gif|jpg|png|jpeg';
				$config1['file_name']=$new_name;*/
                $broker = array(

                    'hotel_id' => $this->session->userdata('user_hotel'),
                    'b_agency' => $this->input->post('b_agency'),
                    'b_agency_name' => $this->input->post('b_agency_name'),
                    'b_name' => $this->input->post('b_name'),
                    'b_address' => $this->input->post('b_address'),
                    'b_contact' => $this->input->post('b_contact'),
                    'b_email' => $this->input->post('b_email'),
                    'b_website' => $this->input->post('b_website'),
                    'b_pan' => $this->input->post('b_pan'),
                    'b_bank_acc_no' => $this->input->post('b_bank_acc_no'),
                    'b_bank_ifsc' => $this->input->post('b_bank_ifsc'),
                    'b_photo' => $room_image,
					'b_photo_thumb' => $room_thumb , 
					'broker_commission' =>  $this->input->post('b_commission')
					
					);
                $query = $this->dashboard_model->add_broker($broker);

                if (isset($query) && $query) {
                    $this->session->set_flashdata('succ_msg', "Broker Added Successfully!");
                    redirect('dashboard/add_broker');
                } else {
                    $this->session->set_flashdata('err_msg', "Database Error. Try again later!");
                    redirect('dashboard/add_broker');
                }

            }
            else{
                $data['page'] = 'backend/dashboard/add_broker';
                $this->load->view('backend/common/index', $data);
            }
        }else{
            redirect('dashboard');
        }
    }

    function all_broker()
    {
        if($this->session->userdata('broker') =='1') {
            $data['heading'] = 'Broker';
            $data['sub_heading'] = 'All Broker';
            $data['description'] = 'Broker List';
            $data['active'] = 'all_broker';
			$data['hotel_name'] = $this->dashboard_model->get_hotel($this->session->userdata('user_hotel'));
            /*if ($this->input->post('pages')) {
                $pages = $this->input->post('pages');
            } else {
                if ($this->session->flashdata('pages')) {
                    $pages = $this->session->flashdata('pages');
                } else {
                    $pages = 5;
                }
            }

            $this->session->set_flashdata('pages', $pages);

            $config['base_url'] = base_url() . 'dashboard/all_broker';
            $config['total_rows'] = $this->dashboard_model->all_broker_row();
            $config['per_page'] = $pages;
            $config['uri_segment'] = 3;
            $config['full_tag_open'] = "<ul class='pagination'>";
            $config['full_tag_close'] = "</ul>";
            $config['num_tag_open'] = '<li>';
            $config['num_tag_close'] = '</li>';
            $config['cur_tag_open'] = "<li class='disabled'><li class='active'><a href='#'>";
            $config['cur_tag_close'] = "<span class='sr-only'></span></a></li>";
            $config['next_tag_open'] = "<li>";
            $config['next_tagl_close'] = "</li>";
            $config['prev_tag_open'] = "<li>";
            $config['prev_tagl_close'] = "</li>";
            $config['first_tag_open'] = "<li>";
            $config['first_tagl_close'] = "</li>";
            $config['last_tag_open'] = "<li>";
            $config['last_tagl_close'] = "</li>";


            $this->pagination->initialize($config);

            $segment = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;

            $data['broker'] = $this->dashboard_model->all_broker_limit($config['per_page'], $segment);
            $data['pagination'] = $this->pagination->create_links();*/
			$data['broker'] = $this->dashboard_model->all_broker_limit();
            $data['page'] = 'backend/dashboard/all_broker';
            $this->load->view('backend/common/index', $data);

        } else {
            redirect('dashboard');
        }
    }

	function showAmount()
	{
		$a = $this->input->post('term')	;
		//$this->load->model('Dashboard);
		$book = $this->dashboard_model->all_t_amount($a);
		//echo $book;
		foreach($book as $row1){
			
    		$data1 = $row1->base_room_rent;
			$data2 = $row1->rent_mode_type;
			$data3 = $row1->mod_room_rent;
   		}
			
		if($data2 == 'P' || $data2 == 'p')
		{
		 echo "Hello";
		 exit();
		}
			
		$data = array(
				'base_room' => $data1,
				'aa'=> $data2,
				'bb'=> $data3
				);
		header('Content-Type: application/json');
		echo json_encode($data1);
		//print_r($book);
		//$this->load->view('backend/dashboard/add_transaction',$book);
		//echo $a;
	}

    function all_reports()
    {
        if($this->session->userdata('booking') =='1') {
            $data['heading'] = 'Customer Report';
            $data['sub_heading'] = 'All Report';
            $data['description'] = 'Report List';
            $data['active'] = 'all_reports';
			$data['hotel_name'] = $this->dashboard_model->get_hotel($this->session->userdata('user_hotel'));
            if($this->input->post()){


                $visit=$this->input->post('r_visit');
                $room=$this->input->post('r_room');

                $all_room=$this->dashboard_model->get_room_id($this->session->userdata('user_hotel'),$room);

                if($all_room) {
                    foreach ($all_room as $r) {
                        $room_id = $r->room_id;

                    }

                }
                else{

                    $room_id=NULL;
                }



                $date_1=date('Y-m-d',strtotime($this->input->post('r_date_1')));
                $date_2=date('Y-m-d',strtotime($this->input->post('r_date_2')));

                $data['bookings'] = $this->dashboard_model->report_search($visit,$room_id,$date_1,$date_2);
                $data['transactions'] = $this->dashboard_model->all_transactions();
                //$data['pagination'] = $this->pagination->create_links();

                $data['page'] = 'backend/dashboard/all_reports';
                $this->load->view('backend/common/index', $data);



            }


            else {


                $data['bookings'] = $this->dashboard_model->all_bookings_report();
                $data['transactions'] = $this->dashboard_model->all_transactions();
                //$data['pagination'] = $this->pagination->create_links();

                $data['page'] = 'backend/dashboard/all_reports';
                $this->load->view('backend/common/index', $data);

            }} else {
            redirect('dashboard');
        }
    }

    function report_search(){



    }
	function all_f_reports()
    {
        if($this->session->userdata('transaction') =='1') {
            $data['heading'] = 'Financial Reports';
            $data['sub_heading'] = 'Daily Financial Reports';
            $data['description'] = 'Report List';
            $data['active'] = 'all_f_reports';
$data['hotel_name'] = $this->dashboard_model->get_hotel($this->session->userdata('user_hotel'));

            /*if ($this->input->post('pages')) {
                $pages = $this->input->post('pages');
            } else {
                if ($this->session->flashdata('pages')) {
                    $pages = $this->session->flashdata('pages');
                } else {
                    $pages = 5;
                }
            }

            $this->session->set_flashdata('pages', $pages);

            $config['base_url'] = base_url() . 'dashboard/all_transactions';
            $config['total_rows'] = $this->dashboard_model->all_transactions_row();
            $config['per_page'] = $pages;
            $config['uri_segment'] = 3;
            $config['full_tag_open'] = "<ul class='pagination'>";
            $config['full_tag_close'] = "</ul>";
            $config['num_tag_open'] = '<li>';
            $config['num_tag_close'] = '</li>';
            $config['cur_tag_open'] = "<li class='disabled'><li class='active'><a href='#'>";
            $config['cur_tag_close'] = "<span class='sr-only'></span></a></li>";
            $config['next_tag_open'] = "<li>";
            $config['next_tagl_close'] = "</li>";
            $config['prev_tag_open'] = "<li>";
            $config['prev_tagl_close'] = "</li>";
            $config['first_tag_open'] = "<li>";
            $config['first_tagl_close'] = "</li>";
            $config['last_tag_open'] = "<li>";
            $config['last_tagl_close'] = "</li>";


            $this->pagination->initialize($config);

            $segment = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;*/

            //$data['transactions'] = $this->dashboard_model->all_transactions_limit($config['per_page'], $segment);
            //$data['pagination'] = $this->pagination->create_links();
            $data['transactions'] = $this->dashboard_model->all_f_reports();
            $data['page'] = 'backend/dashboard/all_f_reports';
            $this->load->view('backend/common/index', $data);

        } else {
            redirect('dashboard');
        }
    }
	
	function generate_excel()
	{
				$this->load->library('excel');
				$this->excel->setActiveSheetIndex(0);
                //name the worksheet
                $this->excel->getActiveSheet()->setTitle('Reports');
                //set cell A1 content with some text
                $this->excel->getActiveSheet()->setCellValue('A1', 'All Report');
                $this->excel->getActiveSheet()->setCellValue('A4', 'S.No.');
                $this->excel->getActiveSheet()->setCellValue('B4', 'Booking Id');
                $this->excel->getActiveSheet()->setCellValue('C4', 'Name');
                $this->excel->getActiveSheet()->setCellValue('D4', 'Room Number');
                $this->excel->getActiveSheet()->setCellValue('E4', 'From And Upto Date');
                $this->excel->getActiveSheet()->setCellValue('F4', 'Address');
                $this->excel->getActiveSheet()->setCellValue('G4', 'Contact Number');
                $this->excel->getActiveSheet()->setCellValue('H4', 'Total Amount');
                $this->excel->getActiveSheet()->setCellValue('I4', 'Amount Dus');
                //merge cell A1 until C1
                $this->excel->getActiveSheet()->mergeCells('A1:I1');
                //set aligment to center for that merged cell (A1 to C1)
				
				$this->excel->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
                //make the font become bold
                $this->excel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
                $this->excel->getActiveSheet()->getStyle('A1')->getFont()->setSize(16);
                $this->excel->getActiveSheet()->getStyle('A1')->getFill()->getStartColor()->setARGB('#333');
				
				for($col = ord('A'); $col <= ord('I'); $col++){
                	//set column dimension
                	$this->excel->getActiveSheet()->getColumnDimension(chr($col))->setAutoSize(true);
                 	//change the font size
                	$this->excel->getActiveSheet()->getStyle(chr($col))->getFont()->setSize(12);
				$this->excel->getActiveSheet()->getStyle(chr($col))->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        		}
				$rs = $this->dashboard_model->get_data_for_excel();
				
				//print_r($rs);
				//exit();
				
				 $exceldata="";
        		foreach ($rs as $row){
                	$exceldata[] = $row;
        		}
				
				$this->excel->getActiveSheet()->fromArray($exceldata, null, 'A4');
                 
                $this->excel->getActiveSheet()->getStyle('A4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
                $this->excel->getActiveSheet()->getStyle('B4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
                $this->excel->getActiveSheet()->getStyle('C4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
				$this->excel->getActiveSheet()->getStyle('D4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
				$this->excel->getActiveSheet()->getStyle('E4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
				$this->excel->getActiveSheet()->getStyle('F4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
				$this->excel->getActiveSheet()->getStyle('G4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
				$this->excel->getActiveSheet()->getStyle('H4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
				$this->excel->getActiveSheet()->getStyle('I4')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
				
				
				$filename='PHPExcelDemo.xls'; //save our workbook as this file name
                header('Content-Type: application/vnd.ms-excel'); //mime type
                header('Content-Disposition: attachment;filename="'.$filename.'"'); //tell browser what's the file name
                header('Cache-Control: max-age=0'); //no cache
 //save it to Excel5 format (excel 2003 .XLS file), change this to 'Excel2007' (and adjust the filename extension, also the header mime type)
                //if you want to save it as .XLSX Excel 2007 format
                $objWriter = PHPExcel_IOFactory::createWriter($this->excel, 'Excel5');  
                //force user to download the Excel file without writing it to server's HD
                $objWriter->save('php://output');
	}
	
	
	function edit_guest()
	{
		if($this->session->userdata('guest') == '1'){
		$data['heading']='Guests';
        $data['sub_heading']='Edit Guest';
        $data['description']='Edit Guest Here';
        $data['active']='edit_guest';
		$data['hotel_name'] = $this->dashboard_model->get_hotel($this->session->userdata('user_hotel'));
		
		
			if($this->input->post()){
				date_default_timezone_set("Asia/Kolkata");
					$guest_edit = array(
					'g_name' => $this->input->post('g_name'),
					'g_address' => $this->input->post('g_address'),
					'g_contact_no' => $this->input->post('g_contact_no'),
					'g_email' => $this->input->post('g_email'),
					'g_gender' => $this->input->post('g_gender'),
					'g_dob' => date("Y-m-d", strtotime($this->input->post('g_dob'))),
					'g_occupation' => $this->input->post('g_occupation'),
					'g_married' => $this->input->post('g_married'),
					'g_pincode' => $this->input->post('g_place'),
					'g_city' => $this->input->post('g_city'),
					'g_state' => $this->input->post('g_state'),
					'g_country' => $this->input->post('g_country')
					);
					//print_r($guest_edit);
					//exit();
					
            		$query = $this->dashboard_model->edit_guest($guest_edit,$this->input->post('guest_id'));
					
					 if (isset($query) && $query) {
                    	$this->session->set_flashdata('succ_msg', "Guest  Update Successfully!");
						$data['value'] = $this->dashboard_model->get_guest_details($this->input->post('guest_id'));
						$data['page'] = 'backend/dashboard/edit_guest';
       					$this->load->view('backend/common/index', $data);
                    	
                	} else {
                    	$this->session->set_flashdata('err_msg', "Database Error. Try again later!");
						$data['value'] = $this->dashboard_model->get_guest_details($g_id);
						$data['page'] = 'backend/dashboard/edit_guest';
       					$this->load->view('backend/common/index', $data);
                    	
                	}
					
				
			}
			else
			{
				$g_id = $_GET['g_id'];
				$data['value'] = $this->dashboard_model->get_guest_details($g_id);
				$data['page'] = 'backend/dashboard/edit_guest';
       			$this->load->view('backend/common/index', $data);
			}
				
			
	
		}else{
			redirect('dashboard');
		}
		
		
	}
	
	
	function edit_broker()
	{
		/*$b_id = $_GET['b_id'];
		echo $b_id;
		exit();*/
		if($this->session->userdata('guest') == '1'){
		$data['heading']='Brokers';
        $data['sub_heading']='Edit Broker';
        $data['description']='Edit Broker Here';
        $data['active']='edit_broker';
		$data['hotel_name'] = $this->dashboard_model->get_hotel($this->session->userdata('user_hotel'));
		
			if($this->input->post()){
				date_default_timezone_set("Asia/Kolkata");
					$broker_edit = array(
                    'b_agency' => $this->input->post('b_agency'),
                    'b_agency_name' => $this->input->post('b_agency_name'),
                    'b_name' => $this->input->post('b_name'),
                    'b_address' => $this->input->post('b_address'),
                    'b_contact' => $this->input->post('b_contact'),
                    'b_email' => $this->input->post('b_email'),
                    'b_website' => $this->input->post('b_website'),
                    'b_pan' => $this->input->post('b_pan'),
                    'b_bank_acc_no' => $this->input->post('b_bank_acc_no'),
                    'b_bank_ifsc' => $this->input->post('b_bank_ifsc'),
					'broker_commission' =>  $this->input->post('b_commission')
                    
					);
                	$query = $this->dashboard_model->edit_broker($broker_edit,$this->input->post('broker_id'));
					
					 if (isset($query) && $query) {
                    	$this->session->set_flashdata('succ_msg', "Broker  Update Successfully!");
						$data['value'] = $this->dashboard_model->get_broker_details($this->input->post('broker_id'));
						$data['page'] = 'backend/dashboard/edit_broker';
       					$this->load->view('backend/common/index', $data);
                    	
                	} else {
                    	$this->session->set_flashdata('err_msg', "Database Error. Try again later!");
						$data['value'] = $this->dashboard_model->get_broker_details($b_id);
						$data['page'] = 'backend/dashboard/edit_broker';
       					$this->load->view('backend/common/index', $data);
                    	
                	}
			
			}else{
				$b_id = $_GET['b_id'];
				$data['value'] = $this->dashboard_model->get_broker_details($b_id);
				$data['page'] = 'backend/dashboard/edit_broker';
       			$this->load->view('backend/common/index', $data);
				
			}
	
		}else{
			redirect('dashboard');
		}
		
		
	}


    function add_hotel_submit()
    {
        $booking_id = $this->input->post('booking_id');
        $add_amount = $this->input->post('add_amount');
        $pay_mode   = $this->input->post('pay_mode');
        $bankname   = $this->input->post('bankname');
        $payment_status = $this->input->post('bankname');

        echo $booking_id,$add_amount,$pay_mode,$bankname,$payment_status;
    }
	
	
	function pdf_reports(){
		
		$data['bookings'] = $this->dashboard_model->all_bookings();
        $data['transactions'] = $this->dashboard_model->all_transactions();		
		//print_r($data);
		//exit();
        $this->load->view("backend/dashboard/all_reports_pdf",$data);
		$html = $this->output->get_output();
		$this->load->library('dompdf_gen');
		$this->dompdf->load_html($html);
		$this->dompdf->render();
		$this->dompdf->stream("all_report.pdf");
	}

	function checkout_submission()
	{
		//echo "hello bunty";
		//$a = $_POST['booking_id'];
		$booking_id  = $this->input->post('booking_id');
		$this->dashboard_model->update_checkout_status($booking_id);
	}

}