<!-- BEGIN PAGE CONTENT-->
<div class="row">
    <div class="col-md-12">

        <div class="portlet box blue-hoki">
            <div class="portlet-title">
                <div class="caption">
                    <i class="fa fa-hotel"></i>Edit Hotel
                </div>
                <div class="tools">
                    <a href="javascript:;" class="collapse">
                    </a>
                    <a href="javascript:;" class="remove">
                    </a>
                </div>
            </div>
            <div class="portlet-body form">
                <!-- BEGIN FORM-->
                <?php
                if(isset($room) && $room){
                    $room_id=$room->room_id;
                    $hotel_id=$room->hotel_id;
                    $floor_no=$room->floor_no;
                    $room_no=$room->room_no;
                    $room_bed=$room->room_bed;
                    $room_availability=$room->room_availability;
                    $ac_availability=$room->ac_availability;
                    $room_rent=$room->room_rent;


                }else{
                    if($this->session->flashdata('room')){
                        $room_id=$this->session->flashdata('room')->room_id;
                        $hotel_id=$this->session->flashdata('room')->hotel_id;
                        $room_no=$this->session->flashdata('room')->room_no;
                        $floor_no=$this->session->flashdata('room')->floor_no;
                        $room_bed=$this->session->flashdata('room')->room_bed;
                        $room_availability=$this->session->flashdata('room')->room_availability;
                        $room_rent=$this->session->flashdata('room')->room_rent;


                    }else{
                        $room_id="";
                        $hotel_id="";
                        $floor_no="";
                        $room_no="";
                        $room_bed="";
                        $room_availability="";
                        $ac_availability="";
                        $room_rent="";

                    }
                }
                $form = array(
                    'class' 			=> 'form-horizontal',
                    'id'				=> 'form',
                    'method'			=> 'post'
                );
                $room_id = array(
                    'type'			=> 'hidden',
                    'name'       	 	=> 'room_id',
                    'required'		=> 'required',
                    'value'			=> $room_id
                );

                $hotel_id = array(
                    'type'			=> 'hidden',
                    'name'       	 	=> 'hotel_id',
                    'required'		=> 'required',
                    'value'			=> $hotel_id
                );


                $floor_no = array(
                    'type'          => 'text',
                    'class'			=> 'form-control input-circle-right',
                    'name'        	=> 'floor_no',
                    'placeholder' 	=> 'Address',
                    'required'		=> 'required',
                    'cols'			=> '',
                    'rows'			=> '',
                    'value'			=> $floor_no
                );

                $room_no = array(
                    'type'			=> 'text',
                    'class'			=> 'form-control input-circle-right',
                    'name'       	 	=> 'room_no',
                    'placeholder' 	=> 'City',
                    'required'		=> 'required',
                    'value'			=> $room_no
                );

                $room_bed = array(
                    'type'			=> 'text',
                    'class'			=> 'form-control input-circle-right',
                    'name'       	 	=> 'room_bed',
                    'placeholder' 	=> 'District',
                    'required'		=> 'required',
                    'value'			=> $room_bed
                );
                $ac_availability = array(
                    ''					=> '--Select Room Type--',
                    'AC'				=> 'AC Room',
                    'NON-AC'			=> 'Non-AC Room'
                );
                $js = 'class="form-control input-circle-right"';

                $room_rent = array(
                    'type'			=> 'text',
                    'class'			=> 'form-control input-circle-right',
                    'name'       	 	=> 'room_rent',
                    'placeholder' 	=> 'Room Rent',
                    'required'		=> 'required',
                    'onkeypress'		=> 'return onlyNos(event,this);',
                    'value' =>$room_rent
                );



                $submit = array(
                    'class'			=> 'btn btn-circle blue',
                    'value'			=> 'Update'
                );

                echo form_open('dashboard/edit_room',$form);
                ?>
                <div class="form-body">
                    <?php if($this->session->flashdata('err_msg')):?>
                        <div class="form-group">
                            <div class="col-md-12 control-label">
                                <div class="alert alert-danger alert-dismissible text-center" role="alert">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                    <strong><?php echo $this->session->flashdata('err_msg');?></strong>
                                </div>
                            </div>
                        </div>
                    <?php endif;?>
                    <?php if($this->session->flashdata('succ_msg')):?>
                        <div class="form-group">
                            <div class="col-md-12 control-label">
                                <div class="alert alert-success alert-dismissible text-center" role="alert">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                    <strong><?php echo $this->session->flashdata('succ_msg');?></strong>
                                </div>
                            </div>
                        </div>
                    <?php endif;?>

                    <div class="form-group">
                        <label class="col-md-3 control-label">
                            Floor No <span class="required">*</span>
                        </label>
                        <div class="col-md-4">
                            <div class="input-group">
															<span class="input-group-addon input-circle-left">
															<i class="fa fa-building"></i>
															</span>
                                <?php echo form_input($floor_no);?>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-3 control-label">
                            Room No <span class="required">*</span>
                        </label>
                        <div class="col-md-4">
                            <div class="input-group">
															<span class="input-group-addon input-circle-left">
															<i class="fa fa-hotel"></i>
															</span>
                                <?php echo form_input($room_no);?>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-3 control-label">
                            Number of Beds <span class="required">*</span>
                        </label>
                        <div class="col-md-4">
                            <div class="input-group">
															<span class="input-group-addon input-circle-left">
															<i class="fa fa-bed"></i>
															</span>
                                <?php echo form_input($room_bed);?>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-3 control-label">
                            AC Availability <span class="required">*</span>
                        </label>
                        <div class="col-md-4">
                            <div class="input-group">
															<span class="input-group-addon input-circle-left">
															<i class="fa fa-bookmark"></i>
															</span>
                                <?php echo form_dropdown('ac_availability', $ac_availability, '', $js);?>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-3 control-label">
                            Room Rent <span class="required">*</span>
                        </label>
                        <div class="col-md-4">
                            <div class="input-group">
															<span class="input-group-addon input-circle-left">
															<i class="fa fa-rupee"></i>
															</span>
                                <?php echo form_input($room_rent);?>
                            </div>
                        </div>
                    </div>
                    <div class="form-actions">
                        <div class="row">
                            <div class="col-md-offset-3 col-md-9">
                                <?php echo form_submit($submit);?>
                                <?php echo form_input($room_id);?>
                            </div>
                        </div>
                    </div>
                    <?php echo form_close();?>
                </div>
            </div>


        </div>
    </div>
    <!-- END PAGE CONTENT-->
</div>
</div>
<!-- END CONTENT -->