<!-- BEGIN PAGE CONTENT-->
<div class="row all_bk">
<!----->
<style>
.all_bk .table>tbody>tr>td{ vertical-align: middle !important;}
.all_bk .table thead tr th{ font-size:13px; text-align:center;}
.all_bk .table-bordered>tbody>tr>td{ font-size:12px;}
.all_bk .md-checkbox label > .box{height: 15px;width: 15px;}
.all_bk .btn{ font-size:12px;}
.all_bk .form-control{ font-size:12px;height: auto;padding: 2px;}
.all_bk .portlet.box > .portlet-title > .caption {
    padding: 18px 0 9px 0;
}
</style>
<!---->
    <div class="col-md-12">
	<!-- BEGIN SAMPLE TABLE PORTLET-->
					<div class="portlet box purple">
						<div class="portlet-title">
							<div class="caption">
								<i class="fa fa-info-circle"></i>View All Employee
							</div>
							<div class="tools col-sm-6">
								<!--<a href="javascript:;" class="collapse">
								</a>
								<a href="#portlet-config" data-toggle="modal" class="config">
								</a><a href="javascript:;" class="remove">
								</a>-->
								<input type="submit" name="submit" value="Delete"  class="btn btn-danger pull-right" data-toggle="confirmation" data-singleton="true">
								<input type="submit" name="submit" value="Mark Inactive " style=" margin-right:10px;" class="btn blue pull-right" data-toggle="confirmation" data-singleton="true">
								<div class="col-sm-4 pull-right"><div class="dataTables_length" id="sample_1_length">
								<label style=" margin:0px;">  
								<select name="sample_1_length" aria-controls="sample_1" class="form-control input-xsmall input-inline">
								<option value="5">5</option><option value="15">15</option>
								<option value="20">20</option>
								<option value="-1">All</option>
								</select> 
								records
								</label>
								</div></div>
								<!--<a href="javascript:;" class="reload">
								</a>-->
								
							</div>
						</div>
						<div class="portlet-body">
							<div class="table-scrollable">
								<table class="table table-striped table-bordered table-hover">
								<thead>
								<tr>
									<th scope="col">
										Select
									</th>
									<th scope="col">
										Valid for 
									</th>
									<th scope="col">
									Valid Name
									</th>
									<th scope="col">
										Certificate Name
									</th>
									<th scope="col">
										Certificate Authority 
									</th>
									<th scope="col">
										Certificate Owner
									</th>
									<th scope="col">
									Certificate Description
									</th>
									<th scope="col">
									Type
									</th>
									
									<th scope="col">
										Importance
									</th>
									<th scope="col">
									Valid Form
									</th>
									<th scope="col">
									Valid Up to
									</th>
									<th scope="col">
									Renewal Date
									</th>
									<th scope="col">
									Certificate
									</th>
									<th scope="col">
										 Action
									</th>
								</tr>
								</thead>
								<tbody>
								<tr>
									<td width="50">
										<div class="md-checkbox pull-left">
											<input type="checkbox" id="checkbox1" class="md-check">
											<label for="checkbox1">
											<span></span>
											<span class="check"></span>
											<span class="box"></span>
											</label>
										</div>
									</td>
									<td>
										Self 
									</td>
									<td>
										T Col 
									</td>
									<td>
										Pan Card
									</td>
									<td>
										Tom  Chauhan
									</td>
									<td>
										 Deep Chanda
									</td>
									<td>
										Lorem Ipsum is simply dummy text of the printing and<br> typesetting industry. Lorem Ipsum has....
									</td>
									<td>
										Pollution
									</td>
									<td>
										High
									</td>
									<td>
										 20.12.2015
									</td>
									<td>
										 20.12.2016
									</td>
									<td>
										 20.12.2016
									</td>
									<td>
										 <img src="http://dev.hotelobjects.com/upload/thumb/troyee_logo_thumb.jpg" alt="">
									</td>
									
									<td>
									
									
									<button type="button" class="btn blue">Edit</button>
									</td>
								</tr>
								
								
								
								
								</tbody>
								</table>
							</div>
						</div>
					</div>
					<!-- END SAMPLE TABLE PORTLET-->
	
        <!-- BEGIN SAMPLE TABLE PORTLET-->
       
<!-- END PAGE CONTENT-->
</div>
</div>
<!-- END CONTENT -->