<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Bookings_model extends CI_Model {
    

/* Select rooms hotel wise */
	function all_rooms_hotelwise($hotel_id){
		$this->db->where('hotel_id',$hotel_id);
		$query = $this->db->get(TABLE_PRE.'room');
		if($query->num_rows()>0){
			 return $query->result();
		}else{
			return false;
		}
	}

	
	function all_rooms_onchange_hotelwise($hotel_id,$capacity){
		$this->db->where('room_bed',$capacity);
		$this->db->where('hotel_id',$hotel_id);
		$query = $this->db->get(TABLE_PRE.'room');
		if($query->num_rows()>0){
			 return $query->result();
		}else{
			return false;
		}
	}
	
	function room_hotelwise($hotel_id,$room_id){
		$this->db->where('hotel_id',$hotel_id);
		$this->db->where('room_id',$room_id);
		$query = $this->db->get(TABLE_PRE.'room');
		if($query->num_rows()>0){
			 return $query->result();
		}else{
			return false;
		}
	}
	
	function broker_hotelwise($hotel_id){
		$this->db->where('hotel_id',$hotel_id);
		$query = $this->db->get(TABLE_PRE.'broker');
		if($query->num_rows()>0){
			 return $query->result();
		}else{
			return false;
		}
	}
	
	function add_new_room($data){
		$query=$this->db->insert(TABLE_PRE.'bookings',$data);
		$last_id = $this->db->insert_id();
        if($query){
            return $last_id;
        }else{
            return false;
        }
	}
	
	function add_new_room2($data){
		$this->db->where('booking_id',$data['booking_id']);
	    $query=$this->db->update(TABLE_PRE.'bookings',$data); 
        if($query){
            return true;
        }else{
            return false;
        }
	}
	
	function add_new_room4($data){
		$query=$this->db->insert(TABLE_PRE.'transactions',$data);
        if($query){
            return true;
        }else{
            return false;
        }
	}
	
	function all_rooms_bookings_event($hotel_id,$start,$end)
	{
		 $sql = "SELECT * FROM ".TABLE_PRE."bookings A
		 JOIN booking_status_type B ON A.booking_status_id = B.status_id
		 WHERE NOT ((A.cust_end_date <= '".$start."') OR (A.cust_from_date >= '".$end."')) AND A.hotel_id='".$hotel_id."'";
		/*$sql = "SELECT * FROM ".TABLE_PRE."bookings WHERE NOT ((cust_end_date <= '".$start."') OR (cust_from_date >= '".$end."')) AND hotel_id='".$hotel_id."'";*/
		 $query=$this->db->query($sql);
		 if($query->num_rows()>0){
			 return $query->result();
		}else{
			return false;
		}
	}
	
	function room_edit_hotelwise($booking_id){
		$sql = "SELECT * FROM ".TABLE_PRE."bookings A 
					JOIN ".TABLE_PRE."room B ON A.room_id = B.room_id   WHERE  A.booking_id='".$booking_id."'"; 
		 $query=$this->db->query($sql);
		if($query->num_rows()>0){
			 return $query->result();
		}else{
			return false;
		}
	}
	
	function add_edit_room($data){
		$this->db->where('booking_id',$data['booking_id']);
	    $query=$this->db->update(TABLE_PRE.'bookings',$data); 
        if($query){
            return true;
        }else{
            return false;
        }
	}
	
	function delete_booking_room($booking_id){
		
		$sql = "DELETE  FROM ".TABLE_PRE."bookings WHERE  booking_id='".$booking_id."'"; 
		 $query=$this->db->query($sql);		
        if($query){
            return true;
        }else{
            return false;
        }
	}
	function update_rooms_bookings_event($booking_id,$start,$end){
		
		$sql = "UPDATE ".TABLE_PRE."bookings SET cust_from_date='".$start."',cust_end_date='".$end."' WHERE  booking_id='".$booking_id."'"; 
		$query=$this->db->query($sql);		
        if($query){
            return true;
        }else{
            return false;
        }
	}
	
	function count_rooms_bookings_event($booking_id,$room_id,$start,$end){
		
		$sql = "SELECT * FROM ".TABLE_PRE."bookings WHERE NOT ((cust_end_date <= '".$start."') OR (cust_from_date >= '".$end."'))
				AND booking_id <> '".$booking_id."' AND room_id = '".$room_id."'"; 
		$query=$this->db->query($sql);	
        if($query){
            return $query->num_rows();
        }else{
            return false;
        }
	}
	
	function update_rooms_bookings_move($booking_id,$room_id,$start,$end){
		
		$sql = "UPDATE ".TABLE_PRE."bookings SET cust_from_date='".$start."',cust_end_date='".$end."',room_id='".$room_id."' WHERE  booking_id='".$booking_id."'"; 
		$query=$this->db->query($sql);		
        if($query){
            return true;
        }else{
            return false;
        }
	}
	
	function  add_guest($data){
        $query=$this->db->insert(TABLE_PRE.'guest',$data);
		$last_id = $this->db->insert_id();
        if($query){
            return $last_id;
        }else{
            return false;
        }
    }
	
	function get_guest($keyword){
		 $sql = "SELECT * FROM ".TABLE_PRE."guest where g_name like'".$keyword."%'";  
		 $query=$this->db->query($sql);
		
		 if($query->num_rows()>0){
			 return $query->result();
		}else{
			return false;
		}
	
	}
	
	function get_guest_details($guest_id){
		 $sql = "SELECT * FROM ".TABLE_PRE."guest where g_id='".$guest_id."'";  
		 $query=$this->db->query($sql);
		
		 if($query->num_rows()>0){
			 return $query->result();
		}else{
			return false;
		}
	
	}
	
	function get_broker_details($b_id){
		 $sql = "SELECT * FROM ".TABLE_PRE."broker where b_id='".$b_id."'";  
		 $query=$this->db->query($sql);
		
		 if($query->num_rows()>0){
			 return $query->result();
		}else{
			return false;
		}
	
	}

	function get_booking_details($book_id)
	{
		$this->db->where('booking_id',$book_id);
		$query = $this->db->get(TABLE_PRE.'bookings');

		if($query->num_rows()>0){
			return $query->result();	 
		}
		else{
			return false;
		}
		
	}

	function get_transaction_details($book_id)
	{
		$this->db->where('t_booking_id',$book_id);
		$query = $this->db->get(TABLE_PRE.'transactions');

		if($query->num_rows()>0){
			return $query->result();	 
		}
		else{
			return false;
		}
	}

	function get_transaction_total_amount($book_id)
	{
		$this->db->select_sum('t_amount');
		$this->db->where('t_booking_id',$book_id);
		$query = $this->db->get(TABLE_PRE.'transactions');

		if($query->num_rows()>0){
			return $query->result();	 
		}
		else{
			return false;
		}
	}

	function get_payment_details($book_id)
	{
		$this->db->select('*');
		$this->db->from(TABLE_PRE.'room');
		$this->db->join(TABLE_PRE.'bookings', 'hotel_room.room_id = hotel_bookings.room_id');
		$this->db->where('booking_id',$book_id);
		$query = $this->db->get();
		
		if($query->num_rows()>0){
			return $query->result();	 
		}
		else{
			return false;
		}
	}

	function get_total_payment($booking_id)
	{
		
		$this->db->where('t_booking_id',$booking_id);
		$this->db->select_sum('t_amount');
		$query = $this->db->get(TABLE_PRE.'transactions');

		if($query->num_rows()>0){
			return $query->result();	 
		}
		else{
			return false;
		}
	}
}

?>